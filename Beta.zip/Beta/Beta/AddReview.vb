﻿Imports System.Data
Imports System.Data.SqlClient
Public Class AddReview
    Public DC As New SqlConnection("server=" & SignIn.DB_ServerName & ";database=" & SignIn.DB_Name & ";user id=" & SignIn.DB_UserId & ";password=" & SignIn.DB_UserPW & ";")
    Private Sub AddReview_Load(sender As Object, e As EventArgs) Handles Me.Load
        txtInfo.Text = "你正在向 " & Main.ProjectName & " 项目的 " & Main.txtIssueInfo.Text.ToString & " 事件添加回顾，请注意核对事件信息！"

    End Sub
    Private Sub btnAddReview_Click(sender As Object, e As EventArgs) Handles btnAddReview.Click
        If txtReviewInfo.Text = String.Empty Then
            MessageBox.Show("不能为空", ToString)
        ElseIf IsNumeric(txtReviewCost.Text()) = False Or IsNumeric(txtReviewDelay.Text()) = False Then
            MessageBox.Show("cost/delay必须为数字", ToString)
        Else
            Dim SqlAddReview As New SqlCommand("INSERT INTO Review (issue_id, review_info, update_author, update_time, review_cost, review_delay, review_category, review_status) VALUES ('" & Main.chosenIssueID & "' , '" & txtReviewInfo.Text & "', '" & Main.UserName & "', '" & Now.ToString & "', '" & txtReviewCost.Text & "', '" & txtReviewDelay.Text & "', '" & cboReviewCategory.Text & "', '打开')", DC)

            DC.Open()
            SqlAddReview.ExecuteNonQuery()
            DC.Close()
            MessageBox.Show("添加成功", ToString)
            '查询和更新Review列表
            Dim reviewDataAdapter As New SqlDataAdapter("SELECT review_id, review_info FROM Review WHERE issue_id = '" & Main.chosenIssueID & "'", DC)
            Dim commentDataSet As New DataSet
            reviewDataAdapter.Fill(commentDataSet, "review")
            Main.dgvReview.DataSource = commentDataSet
            Main.dgvReview.DataMember = "review"
            Me.Hide()
        End If

    End Sub


End Class
﻿Imports System.Data
Imports System.Data.SqlClient

Public Class SignUp
    '注册按钮事件
    Private Sub btnSignUp_Click(sender As Object, e As EventArgs) Handles btnSignUp.Click


        Dim dc As New SqlConnection("server=" & SignIn.DB_ServerName & ";database=" & SignIn.DB_Name & ";user id=" & SignIn.DB_UserId & ";password=" & SignIn.DB_UserPW & ";")
        Dim sql As New SqlCommand("INSERT INTO Users(user_id, user_pw, user_name, user_group) VALUES('" & txtUserID.Text & "','" & txtUserPW.Text & "','" & txtUserName.Text & "','" & txtGroup.Text & "')", dc)
        If txtUserPW.Text = txtRepeatPW.Text Then
            dc.Open()
            sql.ExecuteNonQuery()
            dc.Close()
            MessageBox.Show("ok")
            SignIn.btnSignIn.Focus()
            Me.Hide()
        Else
            MessageBox.Show("两次密码输入不一致")



        End If


    End Sub

End Class
﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UpdateIssue
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtIssueInfo = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtIssueTracker = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cboIssueStatus = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cboIssueResolution = New System.Windows.Forms.ComboBox()
        Me.btnIssueUpdate = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(196, 44)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(113, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Issue information:"
        '
        'txtIssueInfo
        '
        Me.txtIssueInfo.Location = New System.Drawing.Point(332, 41)
        Me.txtIssueInfo.Multiline = True
        Me.txtIssueInfo.Name = "txtIssueInfo"
        Me.txtIssueInfo.Size = New System.Drawing.Size(221, 78)
        Me.txtIssueInfo.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(196, 149)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(89, 12)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Issue tracker:"
        '
        'txtIssueTracker
        '
        Me.txtIssueTracker.Location = New System.Drawing.Point(332, 149)
        Me.txtIssueTracker.Name = "txtIssueTracker"
        Me.txtIssueTracker.Size = New System.Drawing.Size(100, 21)
        Me.txtIssueTracker.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(196, 199)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(83, 12)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Issue status:"
        '
        'cboIssueStatus
        '
        Me.cboIssueStatus.FormattingEnabled = True
        Me.cboIssueStatus.Items.AddRange(New Object() {"open （打开）", "In Progress （进行中）", "Resolved （解决，但未确认）", "Reopen （重新打开）", "Closed （关闭）"})
        Me.cboIssueStatus.Location = New System.Drawing.Point(332, 199)
        Me.cboIssueStatus.Name = "cboIssueStatus"
        Me.cboIssueStatus.Size = New System.Drawing.Size(121, 20)
        Me.cboIssueStatus.TabIndex = 5
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(199, 257)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(107, 12)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Issue resolution:"
        '
        'cboIssueResolution
        '
        Me.cboIssueResolution.FormattingEnabled = True
        Me.cboIssueResolution.Items.AddRange(New Object() {"Fixed （已经解决）", "Won’t Fix （将不会解决）", "Duplicate （重复的）", "Incomplete （不完整的问题）", "Cannot Reproduce （无法重现的问题）"})
        Me.cboIssueResolution.Location = New System.Drawing.Point(332, 248)
        Me.cboIssueResolution.Name = "cboIssueResolution"
        Me.cboIssueResolution.Size = New System.Drawing.Size(121, 20)
        Me.cboIssueResolution.TabIndex = 7
        '
        'btnIssueUpdate
        '
        Me.btnIssueUpdate.Location = New System.Drawing.Point(332, 307)
        Me.btnIssueUpdate.Name = "btnIssueUpdate"
        Me.btnIssueUpdate.Size = New System.Drawing.Size(75, 21)
        Me.btnIssueUpdate.TabIndex = 8
        Me.btnIssueUpdate.Text = "Update"
        Me.btnIssueUpdate.UseVisualStyleBackColor = True
        '
        'UpdateIssue
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 415)
        Me.Controls.Add(Me.btnIssueUpdate)
        Me.Controls.Add(Me.cboIssueResolution)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.cboIssueStatus)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtIssueTracker)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtIssueInfo)
        Me.Controls.Add(Me.Label1)
        Me.Name = "UpdateIssue"
        Me.Text = "UpdateIssue"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents txtIssueInfo As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtIssueTracker As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents cboIssueStatus As ComboBox
    Friend WithEvents Label4 As Label
    Friend WithEvents cboIssueResolution As ComboBox
    Friend WithEvents btnIssueUpdate As Button
End Class

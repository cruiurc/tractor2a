﻿Imports System.Data
Imports System.Data.SqlClient
Public Class AddScheme
    Public DC As New SqlConnection("server=" & SignIn.DB_ServerName & ";database=" & SignIn.DB_Name & ";user id=" & SignIn.DB_UserId & ";password=" & SignIn.DB_UserPW & ";")


    Private Sub AddScheme_Load(sender As Object, e As EventArgs) Handles Me.Load
        txtInfo.Text = "你正在向 " & Main.ProjectName & " 项目的 " & Main.txtIssueInfo.Text.ToString & " 事件添加方案，请注意核对事件信息！"

    End Sub

    Private Sub btnAddScheme_Click(sender As Object, e As EventArgs) Handles btnAddScheme.Click
        If txtSchemeInfo.Text = String.Empty Or txtSchemeTracker.Text = String.Empty Then
            MessageBox.Show("不能为空", ToString)
        Else
            Dim SqlAddScheme As New SqlCommand("INSERT INTO Scheme (issue_id, scheme_info, scheme_tracker, scheme_author, scheme_status, update_author, update_time, start_time) VALUES ('" & Main.chosenIssueID & "' , '" & txtSchemeInfo.Text & "', '" & txtSchemeTracker.Text.Trim & "', '" & Main.UserName & "', '打开', '" & Main.UserName & "', '" & Now.ToString & "', '" & Now.ToString & "')", DC)

            DC.Open()
            SqlAddScheme.ExecuteNonQuery()
            DC.Close()
            MessageBox.Show("添加成功", ToString)
            '查询和更新Scheme列表
            Dim SchemeDataAdapter As New SqlDataAdapter("SELECT scheme_id, scheme_tracker FROM Scheme WHERE issue_id = '" & Main.chosenIssueID & "'", DC)
            Dim SchemeDataSet As New DataSet
            SchemeDataAdapter.Fill(SchemeDataSet, "issue")
            Main.dgvScheme.DataSource = SchemeDataSet
            Main.dgvScheme.DataMember = "issue"
            Me.Hide()
        End If
    End Sub


End Class
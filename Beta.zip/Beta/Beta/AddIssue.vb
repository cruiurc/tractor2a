﻿Imports System.Data
Imports System.Data.SqlClient
Public Class AddIssue
    Public DC As New SqlConnection("server=" & SignIn.DB_ServerName & ";database=" & SignIn.DB_Name & ";user id=" & SignIn.DB_UserId & ";password=" & SignIn.DB_UserPW & ";")

    Private Sub AddIssue_Load(sender As Object, e As EventArgs) Handles Me.Load
        txtInfo.Text = "你正在向 " & Main.ProjectName & " 项目添加事件，请注意核对项目信息！"
    End Sub

    Private Sub btnAddIssue_Click(sender As Object, e As EventArgs) Handles btnAddIssue.Click
        If txtIssueInfo.Text = String.Empty Or txtIssueTracker.Text = String.Empty Then
            MessageBox.Show("不能为空", ToString)
        Else
            Dim SqlAddIssue As New SqlCommand("INSERT INTO Issue (issue_info, project_id, issue_tracker, issue_status, update_author, update_time, start_time) VALUES ('" & txtIssueInfo.Text.Replace("'", "''") & "', '" & Main.chosenProjectID & "', '" & txtIssueTracker.Text.Replace("'", "''") & "', '打开', '" & Main.UserName & "', '" & Now.ToString & "', '" & Now.ToString & "')", DC)

            DC.Open()
            SqlAddIssue.ExecuteNonQuery()
            DC.Close()
            MessageBox.Show("添加成功", ToString)
            '查询和更新项目列表
            Dim issueDataAdapter As New SqlDataAdapter("SELECT issue_id, issue_info, issue_tracker, issue_status FROM Issue WHERE project_id = '" & Main.chosenProjectID & "'", DC)
            Dim issueDataSet As New DataSet
            issueDataAdapter.Fill(issueDataSet, "issue")
            Main.dgvIssue.DataSource = issueDataSet
            Main.dgvIssue.DataMember = "issue"
            Me.Hide()
        End If
    End Sub
End Class
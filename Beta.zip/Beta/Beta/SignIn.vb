﻿'author by crui 2018-12-06 pm @NJ
Imports System.Data
Imports System.Data.SqlClient

Public Class SignIn
    '声明用户ID变量
    Public UserId As Integer
    '声明用于连接数据库的变量
    Public DB_ServerName As String
    Public DB_Name As String
    Public DB_UserId As String
    Public DB_UserPW As String
    Private Sub SignIn_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim a As String = ""
        Dim b As Integer
        FileOpen(1, System.Environment.CurrentDirectory & "\dbinfo.txt", OpenMode.Input)
        Do While Not EOF(1)
            Input(1, a)
            b = b + 1
            If b = 1 Then
                DB_ServerName = a
            ElseIf b = 2 Then
                DB_Name = a
            ElseIf b = 3 Then
                DB_UserId = a
            ElseIf b = 4 Then
                DB_UserPW = a
            End If
        Loop

    End Sub

    '用户登录按钮
    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnSignIn.Click
        '连接数据库并完成查询
        Dim dc As New SqlConnection("server=" & DB_ServerName & ";database=" & DB_Name & ";user id=" & DB_UserId & ";password=" & DB_UserPW & ";")
        Dim da As New SqlDataAdapter("SELECT * FROM Users WHERE user_id = '" & txtUserId.Text.Trim() & "' AND user_pw = '" & txtUserPW.Text.Trim() & "'", dc)
        Dim ds As New DataSet
        da.Fill(ds, "sign")
        '判断查询结果，如果查询不到匹配的数据则报出错误，否则登录成功
        If ds.Tables(0).Rows.Count = 0 Then
            MessageBox.Show("用户名或密码错误，请重新输入")
            txtUserId.Focus()
        Else
            '把用户ID赋值给UserId变量，并在其他窗体中使用

            ds = Nothing
            da = Nothing
            dc = Nothing
            Me.Hide()
            Main.Show()
        End If
    End Sub
    '用户注册链接
    Private Sub llbSignUp_LnkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llbSignUp.LinkClicked
        SignUp.Show()
    End Sub


End Class

﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AddProject
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtProjectNumber = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtProjectName = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtProjectManager = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtProjectAmount = New System.Windows.Forms.TextBox()
        Me.btnAddProject = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(120, 70)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(81, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Project number:"
        '
        'txtProjectNumber
        '
        Me.txtProjectNumber.Location = New System.Drawing.Point(209, 70)
        Me.txtProjectNumber.Name = "txtProjectNumber"
        Me.txtProjectNumber.Size = New System.Drawing.Size(100, 20)
        Me.txtProjectNumber.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(120, 107)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(74, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Project Name:"
        '
        'txtProjectName
        '
        Me.txtProjectName.Location = New System.Drawing.Point(209, 107)
        Me.txtProjectName.Name = "txtProjectName"
        Me.txtProjectName.Size = New System.Drawing.Size(100, 20)
        Me.txtProjectName.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(120, 144)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(87, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Project manager:"
        '
        'txtProjectManager
        '
        Me.txtProjectManager.Location = New System.Drawing.Point(209, 144)
        Me.txtProjectManager.Name = "txtProjectManager"
        Me.txtProjectManager.Size = New System.Drawing.Size(100, 20)
        Me.txtProjectManager.TabIndex = 5
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(120, 184)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(81, 13)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Project amount:"
        '
        'txtProjectAmount
        '
        Me.txtProjectAmount.Location = New System.Drawing.Point(209, 182)
        Me.txtProjectAmount.Name = "txtProjectAmount"
        Me.txtProjectAmount.Size = New System.Drawing.Size(100, 20)
        Me.txtProjectAmount.TabIndex = 7
        '
        'btnAddProject
        '
        Me.btnAddProject.Location = New System.Drawing.Point(123, 226)
        Me.btnAddProject.Name = "btnAddProject"
        Me.btnAddProject.Size = New System.Drawing.Size(75, 23)
        Me.btnAddProject.TabIndex = 8
        Me.btnAddProject.Text = "Add"
        Me.btnAddProject.UseVisualStyleBackColor = True
        '
        'AddProject
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnAddProject)
        Me.Controls.Add(Me.txtProjectAmount)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtProjectManager)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtProjectName)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtProjectNumber)
        Me.Controls.Add(Me.Label1)
        Me.Name = "AddProject"
        Me.Text = "AddProject"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents txtProjectNumber As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtProjectName As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtProjectManager As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txtProjectAmount As TextBox
    Friend WithEvents btnAddProject As Button
End Class

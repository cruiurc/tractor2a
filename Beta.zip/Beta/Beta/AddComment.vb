﻿Imports System.Data
Imports System.Data.SqlClient

Public Class AddComment
    Public DC As New SqlConnection("server=" & SignIn.DB_ServerName & ";database=" & SignIn.DB_Name & ";user id=" & SignIn.DB_UserId & ";password=" & SignIn.DB_UserPW & ";")

    Private Sub AddComment_Load(sender As Object, e As EventArgs) Handles Me.Load
        txtInfo.Text = "你正在向 " & Main.ProjectName & " 项目的 " & Main.txtIssueInfo.Text.ToString & " 事件添加评论，请注意核对事件信息！"
    End Sub

    Private Sub btnAddComment_Click(sender As Object, e As EventArgs) Handles btnAddComment.Click
        If txtCommentInfo.Text = String.Empty Then
            MessageBox.Show("不能为空", ToString)
        Else
            Dim SqlAddComment As New SqlCommand("INSERT INTO Comment (issue_id, comment_info, update_author, update_time) VALUES ('" & Main.chosenIssueID & "' , '" & txtCommentInfo.Text & vbCrLf & "|" & Main.UserName & "|" & Now.ToString & "', '" & Main.UserName & "', '" & Now.ToString & "')", DC)

            DC.Open()
            SqlAddComment.ExecuteNonQuery()
            DC.Close()
            MessageBox.Show("添加成功", ToString)
            '查询和更新Comment列表
            Dim commentDataAdapter As New SqlDataAdapter("SELECT comment_info FROM Comment WHERE issue_id = '" & Main.chosenIssueID & "'", DC)
            Dim commentDataSet As New DataSet
            commentDataAdapter.Fill(commentDataSet, "comment")
            Main.dgvComment.DataSource = commentDataSet
            Main.dgvComment.DataMember = "comment"
            Me.Hide()
        End If
    End Sub



End Class
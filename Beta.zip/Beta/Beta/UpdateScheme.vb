﻿Imports System.Data
Imports System.Data.SqlClient

Public Class UpdateScheme
    Public DC As New SqlConnection("server=" & SignIn.DB_ServerName & ";database=" & SignIn.DB_Name & ";user id=" & SignIn.DB_UserId & ";password=" & SignIn.DB_UserPW & ";")

    Private Sub btnSchemeUpdate_Click(sender As Object, e As EventArgs) Handles btnSchemeUpdate.Click

        If txtSchmeInfo.Text = String.Empty Or cboSchemeStatus.Text = String.Empty Then
            MessageBox.Show("Info/Status不能为空", ToString)
        Else
            Dim SqlUpdateScheme As New SqlCommand("UPDATE Scheme SET scheme_info = '" & txtSchmeInfo.Text & "', scheme_status = '" & cboSchemeStatus.Text & "', scheme_tracker = '" & txtSchemeTracker.Text.Trim() & "', update_author = '" & Main.UserName & "', update_time = '" & Now.ToString & "' WHERE scheme_id = '" & Main.chosenSchemeID & "'", DC)

            DC.Open()
            SqlUpdateScheme.ExecuteNonQuery()
            DC.Close()
            MessageBox.Show("更新成功", ToString)

            '初始化SchemeInfo组合框中标签TEXT的绑定，然后绑定查询结果到这些标签
            Dim SchemeAllDataAdapter As New SqlDataAdapter("SELECT * FROM Scheme WHERE scheme_id = '" & Main.chosenSchemeID & "'", DC)
            Dim SchemeAllDataSet As New DataSet
            SchemeAllDataAdapter.Fill(SchemeAllDataSet, "schemeAll")

            Dim SchemeDataView As New DataView(SchemeAllDataSet.Tables("schemeAll"))
            Main.txtSchemeInfo.DataBindings.Clear()
            Main.lblSchemeAuthor.DataBindings.Clear()
            Main.lblSchemeStartTime.DataBindings.Clear()
            Main.lblSchemeStatus.DataBindings.Clear()
            Main.lblSchemeTracker.DataBindings.Clear()
            Main.lblSchemeUpdateAuthor.DataBindings.Clear()
            Main.lblSchemeUpdateTime.DataBindings.Clear()

            Main.txtSchemeInfo.DataBindings.Add("Text", SchemeDataView, "scheme_info")
            Main.lblSchemeAuthor.DataBindings.Add("Text", SchemeDataView, "scheme_author")
            Main.lblSchemeStartTime.DataBindings.Add("Text", SchemeDataView, "start_time")
            Main.lblSchemeStatus.DataBindings.Add("Text", SchemeDataView, "scheme_status")
            Main.lblSchemeTracker.DataBindings.Add("Text", SchemeDataView, "scheme_tracker")
            Main.lblSchemeUpdateAuthor.DataBindings.Add("Text", SchemeDataView, "update_author")
            Main.lblSchemeUpdateTime.DataBindings.Add("Text", SchemeDataView, "update_time")

            '更新scheme列表
            Dim schemeDataAdapter As New SqlDataAdapter("SELECT scheme_id, scheme_tracker FROM Scheme WHERE issue_id = '" & Main.chosenIssueID & "'", DC)
            Dim schemeDataSet As New DataSet
            schemeDataAdapter.Fill(schemeDataSet, "scheme")
            Main.dgvIssue.DataSource = schemeDataSet
            Main.dgvIssue.DataMember = "scheme"

            Me.Hide()
        End If
    End Sub

End Class
﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AddReview
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。  
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtReviewCost = New System.Windows.Forms.TextBox()
        Me.txtReviewDelay = New System.Windows.Forms.TextBox()
        Me.txtReviewInfo = New System.Windows.Forms.TextBox()
        Me.txtReviewTracker = New System.Windows.Forms.TextBox()
        Me.btnAddReview = New System.Windows.Forms.Button()
        Me.txtInfo = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cboReviewCategory = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(174, 128)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(119, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Review Information:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(174, 249)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(95, 12)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Review tracker:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(174, 68)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(71, 12)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Issue cost:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(174, 96)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(77, 12)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Issue delay:"
        '
        'txtReviewCost
        '
        Me.txtReviewCost.Location = New System.Drawing.Point(323, 68)
        Me.txtReviewCost.Name = "txtReviewCost"
        Me.txtReviewCost.Size = New System.Drawing.Size(100, 21)
        Me.txtReviewCost.TabIndex = 6
        '
        'txtReviewDelay
        '
        Me.txtReviewDelay.Location = New System.Drawing.Point(323, 96)
        Me.txtReviewDelay.Name = "txtReviewDelay"
        Me.txtReviewDelay.Size = New System.Drawing.Size(100, 21)
        Me.txtReviewDelay.TabIndex = 7
        '
        'txtReviewInfo
        '
        Me.txtReviewInfo.Location = New System.Drawing.Point(323, 125)
        Me.txtReviewInfo.Multiline = True
        Me.txtReviewInfo.Name = "txtReviewInfo"
        Me.txtReviewInfo.Size = New System.Drawing.Size(209, 60)
        Me.txtReviewInfo.TabIndex = 8
        '
        'txtReviewTracker
        '
        Me.txtReviewTracker.Location = New System.Drawing.Point(323, 249)
        Me.txtReviewTracker.Name = "txtReviewTracker"
        Me.txtReviewTracker.Size = New System.Drawing.Size(100, 21)
        Me.txtReviewTracker.TabIndex = 10
        '
        'btnAddReview
        '
        Me.btnAddReview.Location = New System.Drawing.Point(323, 286)
        Me.btnAddReview.Name = "btnAddReview"
        Me.btnAddReview.Size = New System.Drawing.Size(75, 23)
        Me.btnAddReview.TabIndex = 11
        Me.btnAddReview.Text = "Add"
        Me.btnAddReview.UseVisualStyleBackColor = True
        '
        'txtInfo
        '
        Me.txtInfo.Location = New System.Drawing.Point(176, 13)
        Me.txtInfo.Multiline = True
        Me.txtInfo.Name = "txtInfo"
        Me.txtInfo.ReadOnly = True
        Me.txtInfo.Size = New System.Drawing.Size(356, 49)
        Me.txtInfo.TabIndex = 12
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(176, 223)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(95, 12)
        Me.Label3.TabIndex = 13
        Me.Label3.Text = "Issue category:"
        '
        'cboReviewCategory
        '
        Me.cboReviewCategory.FormattingEnabled = True
        Me.cboReviewCategory.Items.AddRange(New Object() {"部门A", "部门B"})
        Me.cboReviewCategory.Location = New System.Drawing.Point(323, 223)
        Me.cboReviewCategory.Name = "cboReviewCategory"
        Me.cboReviewCategory.Size = New System.Drawing.Size(121, 20)
        Me.cboReviewCategory.TabIndex = 14
        '
        'AddReview
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.cboReviewCategory)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtInfo)
        Me.Controls.Add(Me.btnAddReview)
        Me.Controls.Add(Me.txtReviewTracker)
        Me.Controls.Add(Me.txtReviewInfo)
        Me.Controls.Add(Me.txtReviewDelay)
        Me.Controls.Add(Me.txtReviewCost)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label1)
        Me.Name = "AddReview"
        Me.Text = "AddReview"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents txtReviewCost As TextBox
    Friend WithEvents txtReviewDelay As TextBox
    Friend WithEvents txtReviewInfo As TextBox
    Friend WithEvents txtReviewTracker As TextBox
    Friend WithEvents btnAddReview As Button
    Friend WithEvents txtInfo As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents cboReviewCategory As ComboBox
End Class

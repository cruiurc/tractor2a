﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AddAction
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。  
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtActionInfo = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtActionTracker = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.dtpActionDue = New System.Windows.Forms.DateTimePicker()
        Me.btnAddAction = New System.Windows.Forms.Button()
        Me.txtInfo = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(221, 169)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(119, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Action information:"
        '
        'txtActionInfo
        '
        Me.txtActionInfo.Location = New System.Drawing.Point(344, 169)
        Me.txtActionInfo.Multiline = True
        Me.txtActionInfo.Name = "txtActionInfo"
        Me.txtActionInfo.Size = New System.Drawing.Size(226, 61)
        Me.txtActionInfo.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(221, 251)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(95, 12)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Action tracker:"
        '
        'txtActionTracker
        '
        Me.txtActionTracker.Location = New System.Drawing.Point(344, 251)
        Me.txtActionTracker.Name = "txtActionTracker"
        Me.txtActionTracker.Size = New System.Drawing.Size(100, 21)
        Me.txtActionTracker.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(221, 301)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(29, 12)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Due:"
        '
        'dtpActionDue
        '
        Me.dtpActionDue.Location = New System.Drawing.Point(344, 301)
        Me.dtpActionDue.Name = "dtpActionDue"
        Me.dtpActionDue.Size = New System.Drawing.Size(200, 21)
        Me.dtpActionDue.TabIndex = 5
        '
        'btnAddAction
        '
        Me.btnAddAction.Location = New System.Drawing.Point(344, 346)
        Me.btnAddAction.Name = "btnAddAction"
        Me.btnAddAction.Size = New System.Drawing.Size(75, 23)
        Me.btnAddAction.TabIndex = 6
        Me.btnAddAction.Text = "Add"
        Me.btnAddAction.UseVisualStyleBackColor = True
        '
        'txtInfo
        '
        Me.txtInfo.Location = New System.Drawing.Point(223, 48)
        Me.txtInfo.Multiline = True
        Me.txtInfo.Name = "txtInfo"
        Me.txtInfo.ReadOnly = True
        Me.txtInfo.Size = New System.Drawing.Size(347, 88)
        Me.txtInfo.TabIndex = 7
        '
        'AddAction
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.txtInfo)
        Me.Controls.Add(Me.btnAddAction)
        Me.Controls.Add(Me.dtpActionDue)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtActionTracker)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtActionInfo)
        Me.Controls.Add(Me.Label1)
        Me.Name = "AddAction"
        Me.Text = "AddAction"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents txtActionInfo As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtActionTracker As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents dtpActionDue As DateTimePicker
    Friend WithEvents btnAddAction As Button
    Friend WithEvents txtInfo As TextBox
End Class

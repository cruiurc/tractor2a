﻿Imports System.Data
Imports System.Data.SqlClient

Public Class AddAction
    Public DC As New SqlConnection("server=" & SignIn.DB_ServerName & ";database=" & SignIn.DB_Name & ";user id=" & SignIn.DB_UserId & ";password=" & SignIn.DB_UserPW & ";")

    Private Sub AddAction_Load(sender As Object, e As EventArgs) Handles Me.Load
        txtInfo.Text = "你正在向 " & Main.ProjectName & " 项目的 " & Main.txtIssueInfo.Text.ToString & " 事件的 " & Main.txtSchemeInfo.Text.ToString & " 方案添加行动，请注意核对方案信息！"

    End Sub

    Private Sub btnAddAction_Click(sender As Object, e As EventArgs) Handles btnAddAction.Click
        If txtActionInfo.Text = String.Empty Then
            MessageBox.Show("不能为空", ToString)
        Else

            Dim SqlAddAction As New SqlCommand("INSERT INTO Action (scheme_id, action_info, action_tracker, action_author, action_status, update_author, update_time, start_time, action_due) VALUES ('" & Main.chosenSchemeID & "' , '" & txtActionInfo.Text & "', '" & txtActionTracker.Text.Trim & "', '" & Main.UserName & "', '打开', '" & Main.UserName & "', '" & Now.ToString & "', '" & Now.ToString & "', '" & dtpActionDue.Text.ToString & "')", DC)


            DC.Open()
            SqlAddAction.ExecuteNonQuery()
            DC.Close()
            MessageBox.Show("添加成功", ToString)
            '查询和更新Action列表
            Dim ActionDataAdapter As New SqlDataAdapter("Select action_id, action_due, action_status FROM Action WHERE scheme_id = '" & Main.chosenSchemeID & "'", DC)
            Dim ActionDataSet As New DataSet
            ActionDataAdapter.Fill(ActionDataSet, "action")
            Main.dgvAction.DataSource = ActionDataSet
            Main.dgvAction.DataMember = "action"
            Me.Hide()

        End If

    End Sub
End Class
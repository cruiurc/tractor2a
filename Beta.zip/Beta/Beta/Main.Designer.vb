﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.tab = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.dgvFocusAction = New System.Windows.Forms.DataGridView()
        Me.dgvFocusScheme = New System.Windows.Forms.DataGridView()
        Me.dgvFocusIssue = New System.Windows.Forms.DataGridView()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.grpIssue = New System.Windows.Forms.GroupBox()
        Me.llbAddIssue = New System.Windows.Forms.LinkLabel()
        Me.dgvIssue = New System.Windows.Forms.DataGridView()
        Me.grpProject = New System.Windows.Forms.GroupBox()
        Me.llbUpdatePorject = New System.Windows.Forms.LinkLabel()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblProjectInfoNumber = New System.Windows.Forms.Label()
        Me.lblProjectInfoName = New System.Windows.Forms.Label()
        Me.lblProjectInfoManager = New System.Windows.Forms.Label()
        Me.lblProjectInfoAmount = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.llbAddProject = New System.Windows.Forms.LinkLabel()
        Me.dgvProject = New System.Windows.Forms.DataGridView()
        Me.txtKeyword = New System.Windows.Forms.TextBox()
        Me.btnSearchProject = New System.Windows.Forms.Button()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.grpComment = New System.Windows.Forms.GroupBox()
        Me.llbAddComment = New System.Windows.Forms.LinkLabel()
        Me.dgvComment = New System.Windows.Forms.DataGridView()
        Me.grpAttachment = New System.Windows.Forms.GroupBox()
        Me.llbAddAttachment = New System.Windows.Forms.LinkLabel()
        Me.dgvAttachment = New System.Windows.Forms.DataGridView()
        Me.grpReview = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel3 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.lblReviewDelay = New System.Windows.Forms.Label()
        Me.lblReviewCost = New System.Windows.Forms.Label()
        Me.lblReviewStatus = New System.Windows.Forms.Label()
        Me.lblReviewTracker = New System.Windows.Forms.Label()
        Me.lblReviewUpdateAuthor = New System.Windows.Forms.Label()
        Me.txtReviewInfo = New System.Windows.Forms.TextBox()
        Me.dgvReview = New System.Windows.Forms.DataGridView()
        Me.llbAddReview = New System.Windows.Forms.LinkLabel()
        Me.grpAction = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.lblActionStatus = New System.Windows.Forms.Label()
        Me.lblActionDue = New System.Windows.Forms.Label()
        Me.lblActionTracker = New System.Windows.Forms.Label()
        Me.lblActionStart = New System.Windows.Forms.Label()
        Me.lblActionAuthor = New System.Windows.Forms.Label()
        Me.lblActionUpdateAuthor = New System.Windows.Forms.Label()
        Me.lblActionUpdateTime = New System.Windows.Forms.Label()
        Me.llbActionUpdate = New System.Windows.Forms.LinkLabel()
        Me.txtActionInfo = New System.Windows.Forms.TextBox()
        Me.llbAddAction = New System.Windows.Forms.LinkLabel()
        Me.dgvAction = New System.Windows.Forms.DataGridView()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel4 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.lblIssueInfoUpdateAuthor = New System.Windows.Forms.Label()
        Me.lblIssueInfoAuthor = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.lblIssueInfoUpdateTime = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.lblIssueInfoTracker = New System.Windows.Forms.Label()
        Me.lblIssueInfoStatus = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.lblIssueInfoStartTime = New System.Windows.Forms.Label()
        Me.lblIssueInfoResolution = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtIssueInfo = New System.Windows.Forms.TextBox()
        Me.llbUpdateIssue = New System.Windows.Forms.LinkLabel()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel5 = New System.Windows.Forms.TableLayoutPanel()
        Me.lblSchemeUpdateAuthor = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.lblSchemeUpdateTime = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.lblSchemeAuthor = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.lblSchemeStartTime = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.lblSchemeStatus = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.lblSchemeTracker = New System.Windows.Forms.Label()
        Me.llbUpdateScheme = New System.Windows.Forms.LinkLabel()
        Me.llbAddScheme = New System.Windows.Forms.LinkLabel()
        Me.txtSchemeInfo = New System.Windows.Forms.TextBox()
        Me.dgvScheme = New System.Windows.Forms.DataGridView()
        Me.lblProjectName = New System.Windows.Forms.Label()
        Me.lblUserName = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.TableLayoutPanel6 = New System.Windows.Forms.TableLayoutPanel()
        Me.tab.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        CType(Me.dgvFocusAction, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvFocusScheme, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvFocusIssue, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        Me.grpIssue.SuspendLayout()
        CType(Me.dgvIssue, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpProject.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.dgvProject, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        Me.grpComment.SuspendLayout()
        CType(Me.dgvComment, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpAttachment.SuspendLayout()
        CType(Me.dgvAttachment, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpReview.SuspendLayout()
        Me.TableLayoutPanel3.SuspendLayout()
        CType(Me.dgvReview, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpAction.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        CType(Me.dgvAction, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox5.SuspendLayout()
        Me.TableLayoutPanel4.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.TableLayoutPanel5.SuspendLayout()
        CType(Me.dgvScheme, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.TableLayoutPanel6.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Location = New System.Drawing.Point(0, 51)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(917, 3)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        '
        'tab
        '
        Me.tab.Controls.Add(Me.TabPage1)
        Me.tab.Controls.Add(Me.TabPage2)
        Me.tab.Controls.Add(Me.TabPage3)
        Me.tab.Cursor = System.Windows.Forms.Cursors.Default
        Me.tab.Location = New System.Drawing.Point(0, 60)
        Me.tab.Multiline = True
        Me.tab.Name = "tab"
        Me.tab.SelectedIndex = 0
        Me.tab.Size = New System.Drawing.Size(917, 639)
        Me.tab.TabIndex = 2
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.GroupBox3)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(909, 613)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Dashboard"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Label32)
        Me.GroupBox3.Controls.Add(Me.Label31)
        Me.GroupBox3.Controls.Add(Me.Label30)
        Me.GroupBox3.Controls.Add(Me.dgvFocusAction)
        Me.GroupBox3.Controls.Add(Me.dgvFocusScheme)
        Me.GroupBox3.Controls.Add(Me.dgvFocusIssue)
        Me.GroupBox3.Location = New System.Drawing.Point(9, 7)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(894, 343)
        Me.GroupBox3.TabIndex = 0
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Foucus"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(601, 20)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(77, 12)
        Me.Label32.TabIndex = 5
        Me.Label32.Text = "Action @ me:"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(298, 21)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(77, 12)
        Me.Label31.TabIndex = 4
        Me.Label31.Text = "Scheme @ me:"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(6, 22)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(71, 12)
        Me.Label30.TabIndex = 3
        Me.Label30.Text = "Issue @ me:"
        '
        'dgvFocusAction
        '
        Me.dgvFocusAction.AllowUserToAddRows = False
        Me.dgvFocusAction.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvFocusAction.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders
        Me.dgvFocusAction.BackgroundColor = System.Drawing.Color.White
        Me.dgvFocusAction.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgvFocusAction.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle1.Font = New System.Drawing.Font("宋体", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvFocusAction.DefaultCellStyle = DataGridViewCellStyle1
        Me.dgvFocusAction.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.dgvFocusAction.Location = New System.Drawing.Point(601, 46)
        Me.dgvFocusAction.Name = "dgvFocusAction"
        Me.dgvFocusAction.ReadOnly = True
        Me.dgvFocusAction.RowHeadersVisible = False
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvFocusAction.RowsDefaultCellStyle = DataGridViewCellStyle2
        Me.dgvFocusAction.RowTemplate.Height = 23
        Me.dgvFocusAction.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvFocusAction.Size = New System.Drawing.Size(285, 276)
        Me.dgvFocusAction.TabIndex = 2
        '
        'dgvFocusScheme
        '
        Me.dgvFocusScheme.AllowUserToAddRows = False
        Me.dgvFocusScheme.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvFocusScheme.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders
        Me.dgvFocusScheme.BackgroundColor = System.Drawing.Color.White
        Me.dgvFocusScheme.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgvFocusScheme.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle3.Font = New System.Drawing.Font("宋体", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvFocusScheme.DefaultCellStyle = DataGridViewCellStyle3
        Me.dgvFocusScheme.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.dgvFocusScheme.Location = New System.Drawing.Point(298, 46)
        Me.dgvFocusScheme.Name = "dgvFocusScheme"
        Me.dgvFocusScheme.ReadOnly = True
        Me.dgvFocusScheme.RowHeadersVisible = False
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvFocusScheme.RowsDefaultCellStyle = DataGridViewCellStyle4
        Me.dgvFocusScheme.RowTemplate.Height = 23
        Me.dgvFocusScheme.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvFocusScheme.Size = New System.Drawing.Size(297, 276)
        Me.dgvFocusScheme.TabIndex = 1
        '
        'dgvFocusIssue
        '
        Me.dgvFocusIssue.AllowUserToAddRows = False
        Me.dgvFocusIssue.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvFocusIssue.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders
        Me.dgvFocusIssue.BackgroundColor = System.Drawing.Color.White
        Me.dgvFocusIssue.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgvFocusIssue.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle5.Font = New System.Drawing.Font("宋体", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvFocusIssue.DefaultCellStyle = DataGridViewCellStyle5
        Me.dgvFocusIssue.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.dgvFocusIssue.Location = New System.Drawing.Point(7, 46)
        Me.dgvFocusIssue.Name = "dgvFocusIssue"
        Me.dgvFocusIssue.ReadOnly = True
        Me.dgvFocusIssue.RowHeadersVisible = False
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvFocusIssue.RowsDefaultCellStyle = DataGridViewCellStyle6
        Me.dgvFocusIssue.RowTemplate.Height = 23
        Me.dgvFocusIssue.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvFocusIssue.Size = New System.Drawing.Size(285, 276)
        Me.dgvFocusIssue.TabIndex = 0
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.grpIssue)
        Me.TabPage2.Controls.Add(Me.grpProject)
        Me.TabPage2.Controls.Add(Me.GroupBox2)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(909, 613)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Project"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'grpIssue
        '
        Me.grpIssue.Controls.Add(Me.llbAddIssue)
        Me.grpIssue.Controls.Add(Me.dgvIssue)
        Me.grpIssue.Location = New System.Drawing.Point(283, 85)
        Me.grpIssue.Name = "grpIssue"
        Me.grpIssue.Size = New System.Drawing.Size(647, 524)
        Me.grpIssue.TabIndex = 5
        Me.grpIssue.TabStop = False
        Me.grpIssue.Text = "Issue List"
        Me.grpIssue.Visible = False
        '
        'llbAddIssue
        '
        Me.llbAddIssue.AutoSize = True
        Me.llbAddIssue.Location = New System.Drawing.Point(6, 15)
        Me.llbAddIssue.Name = "llbAddIssue"
        Me.llbAddIssue.Size = New System.Drawing.Size(71, 12)
        Me.llbAddIssue.TabIndex = 1
        Me.llbAddIssue.TabStop = True
        Me.llbAddIssue.Text = "Add a issue"
        '
        'dgvIssue
        '
        Me.dgvIssue.AllowUserToAddRows = False
        Me.dgvIssue.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvIssue.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders
        Me.dgvIssue.BackgroundColor = System.Drawing.Color.White
        Me.dgvIssue.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgvIssue.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle7.Font = New System.Drawing.Font("宋体", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvIssue.DefaultCellStyle = DataGridViewCellStyle7
        Me.dgvIssue.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.dgvIssue.Location = New System.Drawing.Point(6, 30)
        Me.dgvIssue.Name = "dgvIssue"
        Me.dgvIssue.RowHeadersVisible = False
        Me.dgvIssue.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvIssue.Size = New System.Drawing.Size(614, 488)
        Me.dgvIssue.TabIndex = 0
        '
        'grpProject
        '
        Me.grpProject.Controls.Add(Me.llbUpdatePorject)
        Me.grpProject.Controls.Add(Me.TableLayoutPanel1)
        Me.grpProject.Location = New System.Drawing.Point(283, 6)
        Me.grpProject.Name = "grpProject"
        Me.grpProject.Size = New System.Drawing.Size(647, 73)
        Me.grpProject.TabIndex = 4
        Me.grpProject.TabStop = False
        Me.grpProject.Text = "Project Information"
        Me.grpProject.Visible = False
        '
        'llbUpdatePorject
        '
        Me.llbUpdatePorject.AutoSize = True
        Me.llbUpdatePorject.Location = New System.Drawing.Point(6, 56)
        Me.llbUpdatePorject.Name = "llbUpdatePorject"
        Me.llbUpdatePorject.Size = New System.Drawing.Size(113, 12)
        Me.llbUpdatePorject.TabIndex = 1
        Me.llbUpdatePorject.TabStop = True
        Me.llbUpdatePorject.Text = "Update the Project"
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TableLayoutPanel1.ColumnCount = 4
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Label1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label2, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label3, 2, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label4, 3, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.lblProjectInfoNumber, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.lblProjectInfoName, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.lblProjectInfoManager, 2, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.lblProjectInfoAmount, 3, 1)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(7, 17)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(613, 37)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(4, 4)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(146, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Project Number:"
        '
        'Label2
        '
        Me.Label2.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(157, 4)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(146, 12)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Project Name:"
        '
        'Label3
        '
        Me.Label3.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(310, 4)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(146, 12)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Project Manager:"
        '
        'Label4
        '
        Me.Label4.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(463, 4)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(146, 12)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Amount:"
        '
        'lblProjectInfoNumber
        '
        Me.lblProjectInfoNumber.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblProjectInfoNumber.AutoSize = True
        Me.lblProjectInfoNumber.Location = New System.Drawing.Point(4, 23)
        Me.lblProjectInfoNumber.Name = "lblProjectInfoNumber"
        Me.lblProjectInfoNumber.Size = New System.Drawing.Size(146, 12)
        Me.lblProjectInfoNumber.TabIndex = 4
        Me.lblProjectInfoNumber.Text = "(not chose)"
        '
        'lblProjectInfoName
        '
        Me.lblProjectInfoName.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblProjectInfoName.AutoSize = True
        Me.lblProjectInfoName.Location = New System.Drawing.Point(157, 23)
        Me.lblProjectInfoName.Name = "lblProjectInfoName"
        Me.lblProjectInfoName.Size = New System.Drawing.Size(146, 12)
        Me.lblProjectInfoName.TabIndex = 5
        Me.lblProjectInfoName.Text = "(not chose)"
        '
        'lblProjectInfoManager
        '
        Me.lblProjectInfoManager.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblProjectInfoManager.AutoSize = True
        Me.lblProjectInfoManager.Location = New System.Drawing.Point(310, 23)
        Me.lblProjectInfoManager.Name = "lblProjectInfoManager"
        Me.lblProjectInfoManager.Size = New System.Drawing.Size(146, 12)
        Me.lblProjectInfoManager.TabIndex = 6
        Me.lblProjectInfoManager.Text = "(not chose)"
        '
        'lblProjectInfoAmount
        '
        Me.lblProjectInfoAmount.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblProjectInfoAmount.AutoSize = True
        Me.lblProjectInfoAmount.Location = New System.Drawing.Point(463, 23)
        Me.lblProjectInfoAmount.Name = "lblProjectInfoAmount"
        Me.lblProjectInfoAmount.Size = New System.Drawing.Size(146, 12)
        Me.lblProjectInfoAmount.TabIndex = 7
        Me.lblProjectInfoAmount.Text = "(not chose)"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.llbAddProject)
        Me.GroupBox2.Controls.Add(Me.dgvProject)
        Me.GroupBox2.Controls.Add(Me.txtKeyword)
        Me.GroupBox2.Controls.Add(Me.btnSearchProject)
        Me.GroupBox2.Location = New System.Drawing.Point(6, 6)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(271, 603)
        Me.GroupBox2.TabIndex = 3
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Project List"
        '
        'llbAddProject
        '
        Me.llbAddProject.AutoSize = True
        Me.llbAddProject.Location = New System.Drawing.Point(6, 42)
        Me.llbAddProject.Name = "llbAddProject"
        Me.llbAddProject.Size = New System.Drawing.Size(83, 12)
        Me.llbAddProject.TabIndex = 4
        Me.llbAddProject.TabStop = True
        Me.llbAddProject.Text = "Add a Project"
        '
        'dgvProject
        '
        Me.dgvProject.AllowUserToAddRows = False
        Me.dgvProject.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvProject.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders
        Me.dgvProject.BackgroundColor = System.Drawing.Color.White
        Me.dgvProject.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgvProject.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle8.Font = New System.Drawing.Font("宋体", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        DataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvProject.DefaultCellStyle = DataGridViewCellStyle8
        Me.dgvProject.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.dgvProject.Location = New System.Drawing.Point(7, 56)
        Me.dgvProject.Name = "dgvProject"
        Me.dgvProject.RowHeadersVisible = False
        Me.dgvProject.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvProject.Size = New System.Drawing.Size(251, 541)
        Me.dgvProject.TabIndex = 3
        '
        'txtKeyword
        '
        Me.txtKeyword.Location = New System.Drawing.Point(6, 18)
        Me.txtKeyword.Name = "txtKeyword"
        Me.txtKeyword.Size = New System.Drawing.Size(171, 21)
        Me.txtKeyword.TabIndex = 1
        '
        'btnSearchProject
        '
        Me.btnSearchProject.Location = New System.Drawing.Point(183, 18)
        Me.btnSearchProject.Name = "btnSearchProject"
        Me.btnSearchProject.Size = New System.Drawing.Size(75, 21)
        Me.btnSearchProject.TabIndex = 2
        Me.btnSearchProject.Text = "Search"
        Me.btnSearchProject.UseVisualStyleBackColor = True
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.grpComment)
        Me.TabPage3.Controls.Add(Me.grpAttachment)
        Me.TabPage3.Controls.Add(Me.grpReview)
        Me.TabPage3.Controls.Add(Me.grpAction)
        Me.TabPage3.Controls.Add(Me.GroupBox5)
        Me.TabPage3.Controls.Add(Me.GroupBox7)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(909, 613)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Issue"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'grpComment
        '
        Me.grpComment.Controls.Add(Me.llbAddComment)
        Me.grpComment.Controls.Add(Me.dgvComment)
        Me.grpComment.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.grpComment.Location = New System.Drawing.Point(456, 6)
        Me.grpComment.Name = "grpComment"
        Me.grpComment.Size = New System.Drawing.Size(444, 190)
        Me.grpComment.TabIndex = 10
        Me.grpComment.TabStop = False
        Me.grpComment.Text = "Comment"
        '
        'llbAddComment
        '
        Me.llbAddComment.AutoSize = True
        Me.llbAddComment.Location = New System.Drawing.Point(6, 175)
        Me.llbAddComment.Name = "llbAddComment"
        Me.llbAddComment.Size = New System.Drawing.Size(83, 12)
        Me.llbAddComment.TabIndex = 1
        Me.llbAddComment.TabStop = True
        Me.llbAddComment.Text = "Add a comment"
        '
        'dgvComment
        '
        Me.dgvComment.AllowUserToAddRows = False
        Me.dgvComment.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvComment.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders
        Me.dgvComment.BackgroundColor = System.Drawing.Color.White
        Me.dgvComment.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgvComment.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvComment.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.dgvComment.Location = New System.Drawing.Point(7, 20)
        Me.dgvComment.Name = "dgvComment"
        Me.dgvComment.RowHeadersVisible = False
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvComment.RowsDefaultCellStyle = DataGridViewCellStyle9
        Me.dgvComment.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvComment.Size = New System.Drawing.Size(427, 152)
        Me.dgvComment.TabIndex = 0
        '
        'grpAttachment
        '
        Me.grpAttachment.Controls.Add(Me.llbAddAttachment)
        Me.grpAttachment.Controls.Add(Me.dgvAttachment)
        Me.grpAttachment.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.grpAttachment.Location = New System.Drawing.Point(682, 202)
        Me.grpAttachment.Name = "grpAttachment"
        Me.grpAttachment.Size = New System.Drawing.Size(219, 162)
        Me.grpAttachment.TabIndex = 8
        Me.grpAttachment.TabStop = False
        Me.grpAttachment.Text = "Attachment"
        '
        'llbAddAttachment
        '
        Me.llbAddAttachment.AutoSize = True
        Me.llbAddAttachment.Location = New System.Drawing.Point(6, 142)
        Me.llbAddAttachment.Name = "llbAddAttachment"
        Me.llbAddAttachment.Size = New System.Drawing.Size(107, 12)
        Me.llbAddAttachment.TabIndex = 1
        Me.llbAddAttachment.TabStop = True
        Me.llbAddAttachment.Text = "Add a attachement"
        '
        'dgvAttachment
        '
        Me.dgvAttachment.AllowUserToAddRows = False
        Me.dgvAttachment.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvAttachment.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders
        Me.dgvAttachment.BackgroundColor = System.Drawing.Color.White
        Me.dgvAttachment.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgvAttachment.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvAttachment.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.dgvAttachment.Location = New System.Drawing.Point(7, 18)
        Me.dgvAttachment.Name = "dgvAttachment"
        Me.dgvAttachment.RowHeadersVisible = False
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvAttachment.RowsDefaultCellStyle = DataGridViewCellStyle10
        Me.dgvAttachment.RowTemplate.Height = 23
        Me.dgvAttachment.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvAttachment.Size = New System.Drawing.Size(202, 120)
        Me.dgvAttachment.TabIndex = 0
        '
        'grpReview
        '
        Me.grpReview.Controls.Add(Me.TableLayoutPanel3)
        Me.grpReview.Controls.Add(Me.txtReviewInfo)
        Me.grpReview.Controls.Add(Me.dgvReview)
        Me.grpReview.Controls.Add(Me.llbAddReview)
        Me.grpReview.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.grpReview.Location = New System.Drawing.Point(456, 370)
        Me.grpReview.Name = "grpReview"
        Me.grpReview.Size = New System.Drawing.Size(444, 240)
        Me.grpReview.TabIndex = 7
        Me.grpReview.TabStop = False
        Me.grpReview.Text = "Review"
        '
        'TableLayoutPanel3
        '
        Me.TableLayoutPanel3.ColumnCount = 2
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel3.Controls.Add(Me.Label25, 0, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.Label26, 0, 1)
        Me.TableLayoutPanel3.Controls.Add(Me.Label27, 0, 2)
        Me.TableLayoutPanel3.Controls.Add(Me.Label28, 0, 3)
        Me.TableLayoutPanel3.Controls.Add(Me.Label29, 0, 4)
        Me.TableLayoutPanel3.Controls.Add(Me.lblReviewDelay, 1, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.lblReviewCost, 1, 1)
        Me.TableLayoutPanel3.Controls.Add(Me.lblReviewStatus, 1, 2)
        Me.TableLayoutPanel3.Controls.Add(Me.lblReviewTracker, 1, 3)
        Me.TableLayoutPanel3.Controls.Add(Me.lblReviewUpdateAuthor, 1, 4)
        Me.TableLayoutPanel3.Location = New System.Drawing.Point(185, 91)
        Me.TableLayoutPanel3.Name = "TableLayoutPanel3"
        Me.TableLayoutPanel3.RowCount = 7
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel3.Size = New System.Drawing.Size(250, 129)
        Me.TableLayoutPanel3.TabIndex = 4
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(3, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(35, 12)
        Me.Label25.TabIndex = 0
        Me.Label25.Text = "Cost:"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(3, 12)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(41, 12)
        Me.Label26.TabIndex = 1
        Me.Label26.Text = "Delay:"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(3, 24)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(47, 12)
        Me.Label27.TabIndex = 2
        Me.Label27.Text = "Status:"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(3, 36)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(53, 12)
        Me.Label28.TabIndex = 3
        Me.Label28.Text = "Tracker:"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(3, 48)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(47, 12)
        Me.Label29.TabIndex = 4
        Me.Label29.Text = "Update:"
        '
        'lblReviewDelay
        '
        Me.lblReviewDelay.AutoSize = True
        Me.lblReviewDelay.Location = New System.Drawing.Point(128, 0)
        Me.lblReviewDelay.Name = "lblReviewDelay"
        Me.lblReviewDelay.Size = New System.Drawing.Size(29, 12)
        Me.lblReviewDelay.TabIndex = 5
        Me.lblReviewDelay.Text = "None"
        '
        'lblReviewCost
        '
        Me.lblReviewCost.AutoSize = True
        Me.lblReviewCost.Location = New System.Drawing.Point(128, 12)
        Me.lblReviewCost.Name = "lblReviewCost"
        Me.lblReviewCost.Size = New System.Drawing.Size(29, 12)
        Me.lblReviewCost.TabIndex = 6
        Me.lblReviewCost.Text = "None"
        '
        'lblReviewStatus
        '
        Me.lblReviewStatus.AutoSize = True
        Me.lblReviewStatus.Location = New System.Drawing.Point(128, 24)
        Me.lblReviewStatus.Name = "lblReviewStatus"
        Me.lblReviewStatus.Size = New System.Drawing.Size(29, 12)
        Me.lblReviewStatus.TabIndex = 7
        Me.lblReviewStatus.Text = "None"
        '
        'lblReviewTracker
        '
        Me.lblReviewTracker.AutoSize = True
        Me.lblReviewTracker.Location = New System.Drawing.Point(128, 36)
        Me.lblReviewTracker.Name = "lblReviewTracker"
        Me.lblReviewTracker.Size = New System.Drawing.Size(29, 12)
        Me.lblReviewTracker.TabIndex = 8
        Me.lblReviewTracker.Text = "None"
        '
        'lblReviewUpdateAuthor
        '
        Me.lblReviewUpdateAuthor.AutoSize = True
        Me.lblReviewUpdateAuthor.Location = New System.Drawing.Point(128, 48)
        Me.lblReviewUpdateAuthor.Name = "lblReviewUpdateAuthor"
        Me.lblReviewUpdateAuthor.Size = New System.Drawing.Size(29, 12)
        Me.lblReviewUpdateAuthor.TabIndex = 9
        Me.lblReviewUpdateAuthor.Text = "None"
        '
        'txtReviewInfo
        '
        Me.txtReviewInfo.BackColor = System.Drawing.Color.White
        Me.txtReviewInfo.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtReviewInfo.Location = New System.Drawing.Point(185, 18)
        Me.txtReviewInfo.Multiline = True
        Me.txtReviewInfo.Name = "txtReviewInfo"
        Me.txtReviewInfo.ReadOnly = True
        Me.txtReviewInfo.Size = New System.Drawing.Size(250, 67)
        Me.txtReviewInfo.TabIndex = 3
        '
        'dgvReview
        '
        Me.dgvReview.AllowUserToAddRows = False
        Me.dgvReview.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvReview.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders
        Me.dgvReview.BackgroundColor = System.Drawing.Color.White
        Me.dgvReview.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgvReview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvReview.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.dgvReview.Location = New System.Drawing.Point(7, 18)
        Me.dgvReview.Name = "dgvReview"
        Me.dgvReview.RowHeadersVisible = False
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvReview.RowsDefaultCellStyle = DataGridViewCellStyle11
        Me.dgvReview.RowTemplate.Height = 23
        Me.dgvReview.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvReview.Size = New System.Drawing.Size(172, 202)
        Me.dgvReview.TabIndex = 1
        '
        'llbAddReview
        '
        Me.llbAddReview.AutoSize = True
        Me.llbAddReview.Location = New System.Drawing.Point(6, 223)
        Me.llbAddReview.Name = "llbAddReview"
        Me.llbAddReview.Size = New System.Drawing.Size(77, 12)
        Me.llbAddReview.TabIndex = 0
        Me.llbAddReview.TabStop = True
        Me.llbAddReview.Text = "Add a review"
        '
        'grpAction
        '
        Me.grpAction.Controls.Add(Me.TableLayoutPanel2)
        Me.grpAction.Controls.Add(Me.llbActionUpdate)
        Me.grpAction.Controls.Add(Me.txtActionInfo)
        Me.grpAction.Controls.Add(Me.llbAddAction)
        Me.grpAction.Controls.Add(Me.dgvAction)
        Me.grpAction.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.grpAction.Location = New System.Drawing.Point(8, 370)
        Me.grpAction.Name = "grpAction"
        Me.grpAction.Size = New System.Drawing.Size(442, 240)
        Me.grpAction.TabIndex = 6
        Me.grpAction.TabStop = False
        Me.grpAction.Text = "Action"
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 2
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.Label13, 0, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Label15, 0, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.Label17, 0, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.Label19, 0, 3)
        Me.TableLayoutPanel2.Controls.Add(Me.Label21, 0, 4)
        Me.TableLayoutPanel2.Controls.Add(Me.Label23, 0, 5)
        Me.TableLayoutPanel2.Controls.Add(Me.Label24, 0, 6)
        Me.TableLayoutPanel2.Controls.Add(Me.lblActionStatus, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.lblActionDue, 1, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.lblActionTracker, 1, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.lblActionStart, 1, 3)
        Me.TableLayoutPanel2.Controls.Add(Me.lblActionAuthor, 1, 4)
        Me.TableLayoutPanel2.Controls.Add(Me.lblActionUpdateAuthor, 1, 5)
        Me.TableLayoutPanel2.Controls.Add(Me.lblActionUpdateTime, 1, 6)
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(185, 91)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 7
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(250, 129)
        Me.TableLayoutPanel2.TabIndex = 4
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(3, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(89, 12)
        Me.Label13.TabIndex = 0
        Me.Label13.Text = "Action status:"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(3, 12)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(71, 12)
        Me.Label15.TabIndex = 1
        Me.Label15.Text = "Action due:"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(3, 30)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(53, 12)
        Me.Label17.TabIndex = 2
        Me.Label17.Text = "Tracker:"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(3, 48)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(83, 12)
        Me.Label19.TabIndex = 3
        Me.Label19.Text = "Created time:"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(3, 66)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(47, 12)
        Me.Label21.TabIndex = 4
        Me.Label21.Text = "Author:"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(3, 84)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(89, 12)
        Me.Label23.TabIndex = 5
        Me.Label23.Text = "Update author:"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(3, 102)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(77, 12)
        Me.Label24.TabIndex = 6
        Me.Label24.Text = "Update time:"
        '
        'lblActionStatus
        '
        Me.lblActionStatus.AutoSize = True
        Me.lblActionStatus.Location = New System.Drawing.Point(128, 0)
        Me.lblActionStatus.Name = "lblActionStatus"
        Me.lblActionStatus.Size = New System.Drawing.Size(29, 12)
        Me.lblActionStatus.TabIndex = 7
        Me.lblActionStatus.Text = "None"
        '
        'lblActionDue
        '
        Me.lblActionDue.AutoSize = True
        Me.lblActionDue.Location = New System.Drawing.Point(128, 12)
        Me.lblActionDue.Name = "lblActionDue"
        Me.lblActionDue.Size = New System.Drawing.Size(29, 12)
        Me.lblActionDue.TabIndex = 8
        Me.lblActionDue.Text = "None"
        '
        'lblActionTracker
        '
        Me.lblActionTracker.AutoSize = True
        Me.lblActionTracker.Location = New System.Drawing.Point(128, 30)
        Me.lblActionTracker.Name = "lblActionTracker"
        Me.lblActionTracker.Size = New System.Drawing.Size(29, 12)
        Me.lblActionTracker.TabIndex = 9
        Me.lblActionTracker.Text = "None"
        '
        'lblActionStart
        '
        Me.lblActionStart.AutoSize = True
        Me.lblActionStart.Location = New System.Drawing.Point(128, 48)
        Me.lblActionStart.Name = "lblActionStart"
        Me.lblActionStart.Size = New System.Drawing.Size(29, 12)
        Me.lblActionStart.TabIndex = 10
        Me.lblActionStart.Text = "None"
        '
        'lblActionAuthor
        '
        Me.lblActionAuthor.AutoSize = True
        Me.lblActionAuthor.Location = New System.Drawing.Point(128, 66)
        Me.lblActionAuthor.Name = "lblActionAuthor"
        Me.lblActionAuthor.Size = New System.Drawing.Size(29, 12)
        Me.lblActionAuthor.TabIndex = 11
        Me.lblActionAuthor.Text = "None"
        '
        'lblActionUpdateAuthor
        '
        Me.lblActionUpdateAuthor.AutoSize = True
        Me.lblActionUpdateAuthor.Location = New System.Drawing.Point(128, 84)
        Me.lblActionUpdateAuthor.Name = "lblActionUpdateAuthor"
        Me.lblActionUpdateAuthor.Size = New System.Drawing.Size(29, 12)
        Me.lblActionUpdateAuthor.TabIndex = 12
        Me.lblActionUpdateAuthor.Text = "None"
        '
        'lblActionUpdateTime
        '
        Me.lblActionUpdateTime.AutoSize = True
        Me.lblActionUpdateTime.Location = New System.Drawing.Point(128, 102)
        Me.lblActionUpdateTime.Name = "lblActionUpdateTime"
        Me.lblActionUpdateTime.Size = New System.Drawing.Size(29, 12)
        Me.lblActionUpdateTime.TabIndex = 13
        Me.lblActionUpdateTime.Text = "None"
        '
        'llbActionUpdate
        '
        Me.llbActionUpdate.AutoSize = True
        Me.llbActionUpdate.Location = New System.Drawing.Point(182, 223)
        Me.llbActionUpdate.Name = "llbActionUpdate"
        Me.llbActionUpdate.Size = New System.Drawing.Size(107, 12)
        Me.llbActionUpdate.TabIndex = 0
        Me.llbActionUpdate.TabStop = True
        Me.llbActionUpdate.Text = "Update the action"
        '
        'txtActionInfo
        '
        Me.txtActionInfo.BackColor = System.Drawing.Color.White
        Me.txtActionInfo.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtActionInfo.Location = New System.Drawing.Point(185, 19)
        Me.txtActionInfo.Multiline = True
        Me.txtActionInfo.Name = "txtActionInfo"
        Me.txtActionInfo.ReadOnly = True
        Me.txtActionInfo.Size = New System.Drawing.Size(250, 67)
        Me.txtActionInfo.TabIndex = 2
        '
        'llbAddAction
        '
        Me.llbAddAction.AutoSize = True
        Me.llbAddAction.Location = New System.Drawing.Point(4, 223)
        Me.llbAddAction.Name = "llbAddAction"
        Me.llbAddAction.Size = New System.Drawing.Size(77, 12)
        Me.llbAddAction.TabIndex = 3
        Me.llbAddAction.TabStop = True
        Me.llbAddAction.Text = "Add a action"
        '
        'dgvAction
        '
        Me.dgvAction.AllowUserToAddRows = False
        Me.dgvAction.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvAction.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders
        Me.dgvAction.BackgroundColor = System.Drawing.Color.White
        Me.dgvAction.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgvAction.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvAction.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.dgvAction.Location = New System.Drawing.Point(7, 18)
        Me.dgvAction.Name = "dgvAction"
        Me.dgvAction.RowHeadersVisible = False
        DataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvAction.RowsDefaultCellStyle = DataGridViewCellStyle12
        Me.dgvAction.RowTemplate.Height = 23
        Me.dgvAction.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvAction.Size = New System.Drawing.Size(172, 202)
        Me.dgvAction.TabIndex = 2
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.TableLayoutPanel4)
        Me.GroupBox5.Controls.Add(Me.txtIssueInfo)
        Me.GroupBox5.Controls.Add(Me.llbUpdateIssue)
        Me.GroupBox5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.GroupBox5.Location = New System.Drawing.Point(8, 6)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(442, 190)
        Me.GroupBox5.TabIndex = 0
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Issue"
        '
        'TableLayoutPanel4
        '
        Me.TableLayoutPanel4.ColumnCount = 2
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel4.Controls.Add(Me.Label8, 0, 6)
        Me.TableLayoutPanel4.Controls.Add(Me.lblIssueInfoUpdateAuthor, 1, 6)
        Me.TableLayoutPanel4.Controls.Add(Me.lblIssueInfoAuthor, 1, 4)
        Me.TableLayoutPanel4.Controls.Add(Me.Label11, 0, 4)
        Me.TableLayoutPanel4.Controls.Add(Me.lblIssueInfoUpdateTime, 1, 5)
        Me.TableLayoutPanel4.Controls.Add(Me.Label9, 0, 5)
        Me.TableLayoutPanel4.Controls.Add(Me.Label6, 0, 2)
        Me.TableLayoutPanel4.Controls.Add(Me.Label7, 0, 1)
        Me.TableLayoutPanel4.Controls.Add(Me.lblIssueInfoTracker, 1, 2)
        Me.TableLayoutPanel4.Controls.Add(Me.lblIssueInfoStatus, 1, 1)
        Me.TableLayoutPanel4.Controls.Add(Me.Label10, 0, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.lblIssueInfoStartTime, 1, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.lblIssueInfoResolution, 1, 3)
        Me.TableLayoutPanel4.Controls.Add(Me.Label5, 0, 3)
        Me.TableLayoutPanel4.Location = New System.Drawing.Point(185, 18)
        Me.TableLayoutPanel4.Name = "TableLayoutPanel4"
        Me.TableLayoutPanel4.RowCount = 7
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel4.Size = New System.Drawing.Size(250, 154)
        Me.TableLayoutPanel4.TabIndex = 3
        '
        'Label8
        '
        Me.Label8.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(3, 107)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(119, 12)
        Me.Label8.TabIndex = 3
        Me.Label8.Text = "Update author: "
        '
        'lblIssueInfoUpdateAuthor
        '
        Me.lblIssueInfoUpdateAuthor.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblIssueInfoUpdateAuthor.AutoSize = True
        Me.lblIssueInfoUpdateAuthor.Location = New System.Drawing.Point(128, 107)
        Me.lblIssueInfoUpdateAuthor.Name = "lblIssueInfoUpdateAuthor"
        Me.lblIssueInfoUpdateAuthor.Size = New System.Drawing.Size(119, 12)
        Me.lblIssueInfoUpdateAuthor.TabIndex = 8
        Me.lblIssueInfoUpdateAuthor.Text = "None"
        '
        'lblIssueInfoAuthor
        '
        Me.lblIssueInfoAuthor.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblIssueInfoAuthor.AutoSize = True
        Me.lblIssueInfoAuthor.Location = New System.Drawing.Point(128, 48)
        Me.lblIssueInfoAuthor.Name = "lblIssueInfoAuthor"
        Me.lblIssueInfoAuthor.Size = New System.Drawing.Size(119, 12)
        Me.lblIssueInfoAuthor.TabIndex = 11
        Me.lblIssueInfoAuthor.Text = "None"
        '
        'Label11
        '
        Me.Label11.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(3, 48)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(119, 12)
        Me.Label11.TabIndex = 13
        Me.Label11.Text = "Author: "
        '
        'lblIssueInfoUpdateTime
        '
        Me.lblIssueInfoUpdateTime.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblIssueInfoUpdateTime.AutoSize = True
        Me.lblIssueInfoUpdateTime.Location = New System.Drawing.Point(128, 60)
        Me.lblIssueInfoUpdateTime.Name = "lblIssueInfoUpdateTime"
        Me.lblIssueInfoUpdateTime.Size = New System.Drawing.Size(119, 12)
        Me.lblIssueInfoUpdateTime.TabIndex = 9
        Me.lblIssueInfoUpdateTime.Text = "None"
        '
        'Label9
        '
        Me.Label9.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(3, 60)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(119, 12)
        Me.Label9.TabIndex = 4
        Me.Label9.Text = "Updated time: "
        '
        'Label6
        '
        Me.Label6.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(3, 24)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(119, 12)
        Me.Label6.TabIndex = 1
        Me.Label6.Text = "Issue tracker: "
        '
        'Label7
        '
        Me.Label7.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(3, 12)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(119, 12)
        Me.Label7.TabIndex = 2
        Me.Label7.Text = "Isssue status: "
        '
        'lblIssueInfoTracker
        '
        Me.lblIssueInfoTracker.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblIssueInfoTracker.AutoSize = True
        Me.lblIssueInfoTracker.Location = New System.Drawing.Point(128, 24)
        Me.lblIssueInfoTracker.Name = "lblIssueInfoTracker"
        Me.lblIssueInfoTracker.Size = New System.Drawing.Size(119, 12)
        Me.lblIssueInfoTracker.TabIndex = 6
        Me.lblIssueInfoTracker.Text = "None"
        '
        'lblIssueInfoStatus
        '
        Me.lblIssueInfoStatus.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblIssueInfoStatus.AutoSize = True
        Me.lblIssueInfoStatus.Location = New System.Drawing.Point(128, 12)
        Me.lblIssueInfoStatus.Name = "lblIssueInfoStatus"
        Me.lblIssueInfoStatus.Size = New System.Drawing.Size(119, 12)
        Me.lblIssueInfoStatus.TabIndex = 7
        Me.lblIssueInfoStatus.Text = "None"
        '
        'Label10
        '
        Me.Label10.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(3, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(119, 12)
        Me.Label10.TabIndex = 12
        Me.Label10.Text = "Created time: "
        '
        'lblIssueInfoStartTime
        '
        Me.lblIssueInfoStartTime.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblIssueInfoStartTime.AutoSize = True
        Me.lblIssueInfoStartTime.Location = New System.Drawing.Point(128, 0)
        Me.lblIssueInfoStartTime.Name = "lblIssueInfoStartTime"
        Me.lblIssueInfoStartTime.Size = New System.Drawing.Size(119, 12)
        Me.lblIssueInfoStartTime.TabIndex = 10
        Me.lblIssueInfoStartTime.Text = "None"
        '
        'lblIssueInfoResolution
        '
        Me.lblIssueInfoResolution.AutoSize = True
        Me.lblIssueInfoResolution.Location = New System.Drawing.Point(128, 36)
        Me.lblIssueInfoResolution.Name = "lblIssueInfoResolution"
        Me.lblIssueInfoResolution.Size = New System.Drawing.Size(29, 12)
        Me.lblIssueInfoResolution.TabIndex = 15
        Me.lblIssueInfoResolution.Text = "none"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(3, 36)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(71, 12)
        Me.Label5.TabIndex = 14
        Me.Label5.Text = "Resolution:"
        '
        'txtIssueInfo
        '
        Me.txtIssueInfo.BackColor = System.Drawing.Color.White
        Me.txtIssueInfo.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtIssueInfo.Location = New System.Drawing.Point(9, 18)
        Me.txtIssueInfo.Multiline = True
        Me.txtIssueInfo.Name = "txtIssueInfo"
        Me.txtIssueInfo.ReadOnly = True
        Me.txtIssueInfo.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal
        Me.txtIssueInfo.Size = New System.Drawing.Size(170, 154)
        Me.txtIssueInfo.TabIndex = 2
        '
        'llbUpdateIssue
        '
        Me.llbUpdateIssue.AutoSize = True
        Me.llbUpdateIssue.Location = New System.Drawing.Point(5, 175)
        Me.llbUpdateIssue.Name = "llbUpdateIssue"
        Me.llbUpdateIssue.Size = New System.Drawing.Size(101, 12)
        Me.llbUpdateIssue.TabIndex = 1
        Me.llbUpdateIssue.TabStop = True
        Me.llbUpdateIssue.Text = "Update the issue"
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.TableLayoutPanel5)
        Me.GroupBox7.Controls.Add(Me.llbUpdateScheme)
        Me.GroupBox7.Controls.Add(Me.llbAddScheme)
        Me.GroupBox7.Controls.Add(Me.txtSchemeInfo)
        Me.GroupBox7.Controls.Add(Me.dgvScheme)
        Me.GroupBox7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.GroupBox7.Location = New System.Drawing.Point(8, 202)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(667, 162)
        Me.GroupBox7.TabIndex = 4
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Scheme"
        '
        'TableLayoutPanel5
        '
        Me.TableLayoutPanel5.ColumnCount = 2
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel5.Controls.Add(Me.lblSchemeUpdateAuthor, 1, 5)
        Me.TableLayoutPanel5.Controls.Add(Me.Label20, 0, 5)
        Me.TableLayoutPanel5.Controls.Add(Me.lblSchemeUpdateTime, 1, 4)
        Me.TableLayoutPanel5.Controls.Add(Me.Label18, 0, 4)
        Me.TableLayoutPanel5.Controls.Add(Me.lblSchemeAuthor, 1, 3)
        Me.TableLayoutPanel5.Controls.Add(Me.Label16, 0, 3)
        Me.TableLayoutPanel5.Controls.Add(Me.lblSchemeStartTime, 1, 0)
        Me.TableLayoutPanel5.Controls.Add(Me.Label22, 0, 0)
        Me.TableLayoutPanel5.Controls.Add(Me.lblSchemeStatus, 1, 1)
        Me.TableLayoutPanel5.Controls.Add(Me.Label14, 0, 1)
        Me.TableLayoutPanel5.Controls.Add(Me.Label12, 0, 2)
        Me.TableLayoutPanel5.Controls.Add(Me.lblSchemeTracker, 1, 2)
        Me.TableLayoutPanel5.Location = New System.Drawing.Point(407, 20)
        Me.TableLayoutPanel5.Name = "TableLayoutPanel5"
        Me.TableLayoutPanel5.RowCount = 6
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel5.Size = New System.Drawing.Size(250, 120)
        Me.TableLayoutPanel5.TabIndex = 4
        '
        'lblSchemeUpdateAuthor
        '
        Me.lblSchemeUpdateAuthor.AutoSize = True
        Me.lblSchemeUpdateAuthor.Location = New System.Drawing.Point(128, 102)
        Me.lblSchemeUpdateAuthor.Name = "lblSchemeUpdateAuthor"
        Me.lblSchemeUpdateAuthor.Size = New System.Drawing.Size(29, 12)
        Me.lblSchemeUpdateAuthor.TabIndex = 9
        Me.lblSchemeUpdateAuthor.Text = "None"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(3, 102)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(119, 12)
        Me.Label20.TabIndex = 8
        Me.Label20.Text = "Last update author: "
        '
        'lblSchemeUpdateTime
        '
        Me.lblSchemeUpdateTime.AutoSize = True
        Me.lblSchemeUpdateTime.Location = New System.Drawing.Point(128, 84)
        Me.lblSchemeUpdateTime.Name = "lblSchemeUpdateTime"
        Me.lblSchemeUpdateTime.Size = New System.Drawing.Size(29, 12)
        Me.lblSchemeUpdateTime.TabIndex = 7
        Me.lblSchemeUpdateTime.Text = "None"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(3, 84)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(113, 12)
        Me.Label18.TabIndex = 6
        Me.Label18.Text = "Last update time: "
        '
        'lblSchemeAuthor
        '
        Me.lblSchemeAuthor.AutoSize = True
        Me.lblSchemeAuthor.Location = New System.Drawing.Point(128, 66)
        Me.lblSchemeAuthor.Name = "lblSchemeAuthor"
        Me.lblSchemeAuthor.Size = New System.Drawing.Size(29, 12)
        Me.lblSchemeAuthor.TabIndex = 5
        Me.lblSchemeAuthor.Text = "None"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(3, 66)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(53, 12)
        Me.Label16.TabIndex = 4
        Me.Label16.Text = "Author: "
        '
        'lblSchemeStartTime
        '
        Me.lblSchemeStartTime.AutoSize = True
        Me.lblSchemeStartTime.Location = New System.Drawing.Point(128, 0)
        Me.lblSchemeStartTime.Name = "lblSchemeStartTime"
        Me.lblSchemeStartTime.Size = New System.Drawing.Size(29, 12)
        Me.lblSchemeStartTime.TabIndex = 11
        Me.lblSchemeStartTime.Text = "None"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(3, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(89, 12)
        Me.Label22.TabIndex = 10
        Me.Label22.Text = "Created time: "
        '
        'lblSchemeStatus
        '
        Me.lblSchemeStatus.AutoSize = True
        Me.lblSchemeStatus.Location = New System.Drawing.Point(128, 12)
        Me.lblSchemeStatus.Name = "lblSchemeStatus"
        Me.lblSchemeStatus.Size = New System.Drawing.Size(29, 12)
        Me.lblSchemeStatus.TabIndex = 3
        Me.lblSchemeStatus.Text = "None"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(3, 12)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(95, 12)
        Me.Label14.TabIndex = 2
        Me.Label14.Text = "Scheme status: "
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(3, 48)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(101, 12)
        Me.Label12.TabIndex = 0
        Me.Label12.Text = "Scheme tracker: "
        '
        'lblSchemeTracker
        '
        Me.lblSchemeTracker.AutoSize = True
        Me.lblSchemeTracker.Location = New System.Drawing.Point(128, 48)
        Me.lblSchemeTracker.Name = "lblSchemeTracker"
        Me.lblSchemeTracker.Size = New System.Drawing.Size(29, 12)
        Me.lblSchemeTracker.TabIndex = 1
        Me.lblSchemeTracker.Text = "None"
        '
        'llbUpdateScheme
        '
        Me.llbUpdateScheme.AutoSize = True
        Me.llbUpdateScheme.Location = New System.Drawing.Point(183, 143)
        Me.llbUpdateScheme.Name = "llbUpdateScheme"
        Me.llbUpdateScheme.Size = New System.Drawing.Size(107, 12)
        Me.llbUpdateScheme.TabIndex = 2
        Me.llbUpdateScheme.TabStop = True
        Me.llbUpdateScheme.Text = "Update the Scheme"
        '
        'llbAddScheme
        '
        Me.llbAddScheme.AutoSize = True
        Me.llbAddScheme.Location = New System.Drawing.Point(7, 143)
        Me.llbAddScheme.Name = "llbAddScheme"
        Me.llbAddScheme.Size = New System.Drawing.Size(77, 12)
        Me.llbAddScheme.TabIndex = 3
        Me.llbAddScheme.TabStop = True
        Me.llbAddScheme.Text = "Add a scheme"
        '
        'txtSchemeInfo
        '
        Me.txtSchemeInfo.BackColor = System.Drawing.Color.White
        Me.txtSchemeInfo.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtSchemeInfo.Location = New System.Drawing.Point(185, 18)
        Me.txtSchemeInfo.Multiline = True
        Me.txtSchemeInfo.Name = "txtSchemeInfo"
        Me.txtSchemeInfo.ReadOnly = True
        Me.txtSchemeInfo.Size = New System.Drawing.Size(216, 122)
        Me.txtSchemeInfo.TabIndex = 3
        '
        'dgvScheme
        '
        Me.dgvScheme.AllowUserToAddRows = False
        Me.dgvScheme.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvScheme.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders
        Me.dgvScheme.BackgroundColor = System.Drawing.Color.White
        Me.dgvScheme.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgvScheme.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvScheme.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.dgvScheme.Location = New System.Drawing.Point(9, 18)
        Me.dgvScheme.Name = "dgvScheme"
        Me.dgvScheme.RowHeadersVisible = False
        Me.dgvScheme.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvScheme.RowsDefaultCellStyle = DataGridViewCellStyle13
        Me.dgvScheme.RowTemplate.Height = 23
        Me.dgvScheme.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvScheme.Size = New System.Drawing.Size(170, 122)
        Me.dgvScheme.TabIndex = 0
        '
        'lblProjectName
        '
        Me.lblProjectName.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblProjectName.AutoSize = True
        Me.lblProjectName.Font = New System.Drawing.Font("Calibri", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProjectName.ForeColor = System.Drawing.Color.White
        Me.lblProjectName.Location = New System.Drawing.Point(457, 10)
        Me.lblProjectName.Name = "lblProjectName"
        Me.lblProjectName.Size = New System.Drawing.Size(196, 29)
        Me.lblProjectName.TabIndex = 1
        Me.lblProjectName.Text = "Project not chosed"
        Me.lblProjectName.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblUserName
        '
        Me.lblUserName.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblUserName.AutoSize = True
        Me.lblUserName.Font = New System.Drawing.Font("Calibri", 18.0!)
        Me.lblUserName.ForeColor = System.Drawing.Color.White
        Me.lblUserName.Location = New System.Drawing.Point(394, 0)
        Me.lblUserName.Name = "lblUserName"
        Me.lblUserName.Size = New System.Drawing.Size(57, 29)
        Me.lblUserName.TabIndex = 0
        Me.lblUserName.Text = "User"
        Me.lblUserName.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.LightSlateGray
        Me.Panel1.Controls.Add(Me.TableLayoutPanel6)
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(917, 45)
        Me.Panel1.TabIndex = 4
        '
        'TableLayoutPanel6
        '
        Me.TableLayoutPanel6.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel6.ColumnCount = 2
        Me.TableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel6.Controls.Add(Me.lblUserName, 0, 0)
        Me.TableLayoutPanel6.Controls.Add(Me.lblProjectName, 1, 0)
        Me.TableLayoutPanel6.Location = New System.Drawing.Point(4, 3)
        Me.TableLayoutPanel6.Name = "TableLayoutPanel6"
        Me.TableLayoutPanel6.RowCount = 1
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel6.Size = New System.Drawing.Size(909, 39)
        Me.TableLayoutPanel6.TabIndex = 2
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(917, 705)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.tab)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "Main"
        Me.Text = "Main"
        Me.tab.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.dgvFocusAction, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvFocusScheme, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvFocusIssue, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.grpIssue.ResumeLayout(False)
        Me.grpIssue.PerformLayout()
        CType(Me.dgvIssue, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpProject.ResumeLayout(False)
        Me.grpProject.PerformLayout()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.dgvProject, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        Me.grpComment.ResumeLayout(False)
        Me.grpComment.PerformLayout()
        CType(Me.dgvComment, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpAttachment.ResumeLayout(False)
        Me.grpAttachment.PerformLayout()
        CType(Me.dgvAttachment, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpReview.ResumeLayout(False)
        Me.grpReview.PerformLayout()
        Me.TableLayoutPanel3.ResumeLayout(False)
        Me.TableLayoutPanel3.PerformLayout()
        CType(Me.dgvReview, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpAction.ResumeLayout(False)
        Me.grpAction.PerformLayout()
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.TableLayoutPanel2.PerformLayout()
        CType(Me.dgvAction, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.TableLayoutPanel4.ResumeLayout(False)
        Me.TableLayoutPanel4.PerformLayout()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.TableLayoutPanel5.ResumeLayout(False)
        Me.TableLayoutPanel5.PerformLayout()
        CType(Me.dgvScheme, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.TableLayoutPanel6.ResumeLayout(False)
        Me.TableLayoutPanel6.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents tab As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents btnSearchProject As Button
    Friend WithEvents txtKeyword As TextBox
    Friend WithEvents grpIssue As GroupBox
    Friend WithEvents grpProject As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents dgvProject As DataGridView
    Friend WithEvents llbAddProject As LinkLabel
    Friend WithEvents llbUpdatePorject As LinkLabel
    Friend WithEvents dgvIssue As DataGridView

    Friend WithEvents lblProjectName As Label
    Friend WithEvents lblUserName As Label
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents lblProjectInfoNumber As Label
    Friend WithEvents lblProjectInfoName As Label
    Friend WithEvents lblProjectInfoManager As Label
    Friend WithEvents lblProjectInfoAmount As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents llbAddIssue As LinkLabel
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents grpAttachment As GroupBox
    Friend WithEvents llbAddAttachment As LinkLabel
    Friend WithEvents dgvAttachment As DataGridView
    Friend WithEvents grpReview As GroupBox
    Friend WithEvents dgvReview As DataGridView
    Friend WithEvents llbAddReview As LinkLabel
    Friend WithEvents grpAction As GroupBox
    Friend WithEvents llbAddAction As LinkLabel
    Friend WithEvents dgvAction As DataGridView
    Friend WithEvents llbUpdateScheme As LinkLabel
    Friend WithEvents GroupBox7 As GroupBox
    Friend WithEvents llbAddScheme As LinkLabel
    Friend WithEvents dgvScheme As DataGridView
    Friend WithEvents llbUpdateIssue As LinkLabel
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents lblIssueInfoTracker As Label
    Friend WithEvents lblIssueInfoStatus As Label
    Friend WithEvents lblIssueInfoUpdateAuthor As Label
    Friend WithEvents lblIssueInfoUpdateTime As Label
    Friend WithEvents lblIssueInfoStartTime As Label
    Friend WithEvents lblIssueInfoAuthor As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents txtIssueInfo As TextBox
    Friend WithEvents txtActionInfo As TextBox
    Friend WithEvents llbActionUpdate As LinkLabel
    Friend WithEvents txtSchemeInfo As TextBox
    Friend WithEvents grpComment As GroupBox
    Friend WithEvents llbAddComment As LinkLabel
    Friend WithEvents dgvComment As DataGridView
    Friend WithEvents Label5 As Label
    Friend WithEvents lblIssueInfoResolution As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents lblSchemeTracker As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents lblSchemeStatus As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents lblSchemeAuthor As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents lblSchemeUpdateTime As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents lblSchemeUpdateAuthor As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents lblSchemeStartTime As Label
    Friend WithEvents txtReviewInfo As TextBox
    Friend WithEvents TableLayoutPanel2 As TableLayoutPanel
    Friend WithEvents Label13 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents lblActionStatus As Label
    Friend WithEvents lblActionDue As Label
    Friend WithEvents lblActionTracker As Label
    Friend WithEvents lblActionStart As Label
    Friend WithEvents lblActionAuthor As Label
    Friend WithEvents lblActionUpdateAuthor As Label
    Friend WithEvents lblActionUpdateTime As Label
    Friend WithEvents TableLayoutPanel3 As TableLayoutPanel
    Friend WithEvents Label25 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents lblReviewDelay As Label
    Friend WithEvents lblReviewCost As Label
    Friend WithEvents lblReviewStatus As Label
    Friend WithEvents lblReviewTracker As Label
    Friend WithEvents lblReviewUpdateAuthor As Label
    Friend WithEvents TableLayoutPanel4 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel5 As TableLayoutPanel
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents Label32 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents dgvFocusAction As DataGridView
    Friend WithEvents dgvFocusScheme As DataGridView
    Friend WithEvents dgvFocusIssue As DataGridView
    Friend WithEvents TableLayoutPanel6 As TableLayoutPanel
End Class

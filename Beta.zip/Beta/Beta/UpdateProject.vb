﻿

Imports System.Data
Imports System.Data.SqlClient
Public Class UpdateProject
    Public DC As New SqlConnection("server=" & SignIn.DB_ServerName & ";database=" & SignIn.DB_Name & ";user id=" & SignIn.DB_UserId & ";password=" & SignIn.DB_UserPW & ";")

    Private Sub btnUpdateProject_Click(sender As Object, e As EventArgs) Handles btnUpdateProject.Click
        If txtProjectName.Text = String.Empty Or txtProjectNumber.Text = String.Empty Or txtProjectManager.Text = String.Empty Or txtProjectAmount.Text = String.Empty Then
            MessageBox.Show("不能为空", ToString)
        Else
            Dim SqlUpdateProject As New SqlCommand("UPDATE Project SET project_name = '" & txtProjectName.Text.Trim() & "', project_number = '" & txtProjectNumber.Text.Trim() & "', project_manager = '" & txtProjectManager.Text & "', project_amount = '" & txtProjectAmount.Text.Trim() & "', update_author = '" & Main.UserName & "', update_time = '" & Now.ToString & "' WHERE project_id = '" & Main.chosenProjectID & "'", DC)

            DC.Open()
            SqlUpdateProject.ExecuteNonQuery()
            DC.Close()
            MessageBox.Show("更新成功", ToString)
            '查询和更新项目列表
            Dim projectDataAdapter As New SqlDataAdapter("SELECT project_id, project_number, project_name FROM Project WHERE project_id = '" & Main.chosenProjectID & "'", DC)
            Dim projectDataSet As New DataSet
            projectDataAdapter.Fill(projectDataSet, "project")
            Main.dgvProject.DataSource = projectDataSet
            Main.dgvProject.DataMember = "project"
            Main.dgvProject.Refresh()
            '初始化ProjectInfo组合框中标签TEXT的绑定，然后绑定查询结果到这些标签
            Dim projectALLDataAdapter As New SqlDataAdapter("SELECT * FROM Project WHERE project_id = '" & Main.chosenProjectID & "'", DC)
            Dim projectALLDataSet As New DataSet
            projectALLDataAdapter.Fill(projectALLDataSet, "projectAll")
            Dim projectDataView As New DataView(projectALLDataSet.Tables("projectAll"))
            Main.lblProjectInfoName.DataBindings.Clear()
            Main.lblProjectInfoNumber.DataBindings.Clear()
            Main.lblProjectInfoManager.DataBindings.Clear()
            Main.lblProjectInfoAmount.DataBindings.Clear()
            Main.lblProjectInfoName.DataBindings.Add("Text", projectDataView, "project_name")
            Main.lblProjectInfoNumber.DataBindings.Add("Text", projectDataView, "project_number")
            Main.lblProjectInfoManager.DataBindings.Add("Text", projectDataView, "project_manager")
            Main.lblProjectInfoAmount.DataBindings.Add("Text", projectDataView, "project_amount")
            '在右上角的标签中显示项目名称
            Main.ProjectName = Main.lblProjectInfoName.Text
            Main.lblProjectName.Text = Main.ProjectName
            Me.Hide()
        End If

    End Sub
End Class
﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UpdateAction
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。  
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtActionInfo = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtActionTracker = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtActionDue = New System.Windows.Forms.TextBox()
        Me.dtpActionDue = New System.Windows.Forms.DateTimePicker()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cboActionStatus = New System.Windows.Forms.ComboBox()
        Me.btnUpdateAction = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(179, 105)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(119, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Action information:"
        '
        'txtActionInfo
        '
        Me.txtActionInfo.Location = New System.Drawing.Point(368, 105)
        Me.txtActionInfo.Multiline = True
        Me.txtActionInfo.Name = "txtActionInfo"
        Me.txtActionInfo.Size = New System.Drawing.Size(217, 83)
        Me.txtActionInfo.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(179, 197)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(95, 12)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Action tracker:"
        '
        'txtActionTracker
        '
        Me.txtActionTracker.Location = New System.Drawing.Point(368, 197)
        Me.txtActionTracker.Name = "txtActionTracker"
        Me.txtActionTracker.Size = New System.Drawing.Size(100, 21)
        Me.txtActionTracker.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(181, 236)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(29, 12)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Due:"
        '
        'txtActionDue
        '
        Me.txtActionDue.Location = New System.Drawing.Point(368, 236)
        Me.txtActionDue.Name = "txtActionDue"
        Me.txtActionDue.Size = New System.Drawing.Size(146, 21)
        Me.txtActionDue.TabIndex = 5
        '
        'dtpActionDue
        '
        Me.dtpActionDue.Location = New System.Drawing.Point(520, 236)
        Me.dtpActionDue.Name = "dtpActionDue"
        Me.dtpActionDue.Size = New System.Drawing.Size(18, 21)
        Me.dtpActionDue.TabIndex = 6
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(181, 273)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(47, 12)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Status:"
        '
        'cboActionStatus
        '
        Me.cboActionStatus.FormattingEnabled = True
        Me.cboActionStatus.Items.AddRange(New Object() {"打开", "关闭"})
        Me.cboActionStatus.Location = New System.Drawing.Point(368, 273)
        Me.cboActionStatus.Name = "cboActionStatus"
        Me.cboActionStatus.Size = New System.Drawing.Size(121, 20)
        Me.cboActionStatus.TabIndex = 8
        '
        'btnUpdateAction
        '
        Me.btnUpdateAction.Location = New System.Drawing.Point(368, 320)
        Me.btnUpdateAction.Name = "btnUpdateAction"
        Me.btnUpdateAction.Size = New System.Drawing.Size(75, 23)
        Me.btnUpdateAction.TabIndex = 9
        Me.btnUpdateAction.Text = "Update"
        Me.btnUpdateAction.UseVisualStyleBackColor = True
        '
        'UpdateAction
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnUpdateAction)
        Me.Controls.Add(Me.cboActionStatus)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.dtpActionDue)
        Me.Controls.Add(Me.txtActionDue)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtActionTracker)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtActionInfo)
        Me.Controls.Add(Me.Label1)
        Me.Name = "UpdateAction"
        Me.Text = "UpdateAction"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents txtActionInfo As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtActionTracker As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtActionDue As TextBox
    Friend WithEvents dtpActionDue As DateTimePicker
    Friend WithEvents Label4 As Label
    Friend WithEvents cboActionStatus As ComboBox
    Friend WithEvents btnUpdateAction As Button
End Class

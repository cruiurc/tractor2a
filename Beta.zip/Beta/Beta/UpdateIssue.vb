﻿Imports System.Data
Imports System.Data.SqlClient

Public Class UpdateIssue
    Public DC As New SqlConnection("server=" & SignIn.DB_ServerName & ";database=" & SignIn.DB_Name & ";user id=" & SignIn.DB_UserId & ";password=" & SignIn.DB_UserPW & ";")

    Private Sub btnIssueUpdate_Click(sender As Object, e As EventArgs) Handles btnIssueUpdate.Click
        If txtIssueInfo.Text = String.Empty Or cboIssueStatus.Text = String.Empty Then
            MessageBox.Show("Info/Status不能为空", ToString)
        Else
            Dim SqlUpdateIssue As New SqlCommand("UPDATE Issue SET issue_info = '" & txtIssueInfo.Text & "', issue_status = '" & cboIssueStatus.Text & "', issue_tracker = '" & txtIssueTracker.Text.Trim() & "', update_author = '" & Main.UserName & "', update_time = '" & Now.ToString & "', issue_resolution = '" & cboIssueResolution.Text & "' WHERE issue_id = '" & Main.chosenIssueID & "'", DC)

            DC.Open()
            SqlUpdateIssue.ExecuteNonQuery()
            DC.Close()
            MessageBox.Show("更新成功", ToString)

            '初始化ProjectInfo组合框中标签TEXT的绑定，然后绑定查询结果到这些标签
            Dim issueDataAdapterALL As New SqlDataAdapter("SELECT * FROM Issue WHERE issue_id = '" & Main.chosenIssueID & "'", DC)
            Dim issueDataSetALL As New DataSet
            issueDataAdapterALL.Fill(issueDataSetALL, "issue")
            Dim issueDataView As New DataView(issueDataSetALL.Tables("issue"))
            txtIssueInfo.DataBindings.Clear()
            Main.lblIssueInfoTracker.DataBindings.Clear()
            Main.lblIssueInfoStatus.DataBindings.Clear()
            Main.lblIssueInfoUpdateAuthor.DataBindings.Clear()
            Main.lblIssueInfoUpdateTime.DataBindings.Clear()
            Main.lblIssueInfoStartTime.DataBindings.Clear()
            Main.lblIssueInfoAuthor.DataBindings.Clear()
            Main.lblIssueInfoResolution.DataBindings.Clear()
            txtIssueInfo.DataBindings.Add("Text", issueDataView, "issue_info")
            Main.lblIssueInfoTracker.DataBindings.Add("Text", issueDataView, "issue_tracker")
            Main.lblIssueInfoStatus.DataBindings.Add("Text", issueDataView, "issue_status")
            Main.lblIssueInfoUpdateAuthor.DataBindings.Add("Text", issueDataView, "update_author")
            Main.lblIssueInfoUpdateTime.DataBindings.Add("Text", issueDataView, "update_time")
            Main.lblIssueInfoStartTime.DataBindings.Add("Text", issueDataView, "start_time")
            Main.lblIssueInfoAuthor.DataBindings.Add("Text", issueDataView, "issue_author")
            Main.lblIssueInfoResolution.DataBindings.Add("Text", issueDataView, "issue_resolution")

            '更新issue列表
            Dim issueDataAdapter As New SqlDataAdapter("SELECT issue_id, issue_tracker, issue_status FROM Issue WHERE issue_id = '" & Main.chosenIssueID & "'", DC)
            Dim issueDataSet As New DataSet
            issueDataAdapter.Fill(issueDataSet, "issue")
            Main.dgvIssue.DataSource = issueDataSet
            Main.dgvIssue.DataMember = "issue"

            Me.Hide()
        End If
    End Sub
End Class
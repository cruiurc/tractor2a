﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class UpdateScheme
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。  
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtSchmeInfo = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtSchemeTracker = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnSchemeUpdate = New System.Windows.Forms.Button()
        Me.cboSchemeStatus = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(161, 85)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(119, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Scheme information:"
        '
        'txtSchmeInfo
        '
        Me.txtSchmeInfo.Location = New System.Drawing.Point(290, 85)
        Me.txtSchmeInfo.Multiline = True
        Me.txtSchmeInfo.Name = "txtSchmeInfo"
        Me.txtSchmeInfo.Size = New System.Drawing.Size(230, 71)
        Me.txtSchmeInfo.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(163, 162)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(95, 12)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Scheme tracker:"
        '
        'txtSchemeTracker
        '
        Me.txtSchemeTracker.Location = New System.Drawing.Point(290, 162)
        Me.txtSchemeTracker.Name = "txtSchemeTracker"
        Me.txtSchemeTracker.Size = New System.Drawing.Size(100, 21)
        Me.txtSchemeTracker.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(163, 208)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(89, 12)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Scheme status:"
        '
        'btnSchemeUpdate
        '
        Me.btnSchemeUpdate.Location = New System.Drawing.Point(290, 262)
        Me.btnSchemeUpdate.Name = "btnSchemeUpdate"
        Me.btnSchemeUpdate.Size = New System.Drawing.Size(75, 23)
        Me.btnSchemeUpdate.TabIndex = 6
        Me.btnSchemeUpdate.Text = "Update"
        Me.btnSchemeUpdate.UseVisualStyleBackColor = True
        '
        'cboSchemeStatus
        '
        Me.cboSchemeStatus.FormattingEnabled = True
        Me.cboSchemeStatus.Items.AddRange(New Object() {"打开", "关闭"})
        Me.cboSchemeStatus.Location = New System.Drawing.Point(290, 208)
        Me.cboSchemeStatus.Name = "cboSchemeStatus"
        Me.cboSchemeStatus.Size = New System.Drawing.Size(121, 20)
        Me.cboSchemeStatus.TabIndex = 7
        '
        'UpdateScheme
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.cboSchemeStatus)
        Me.Controls.Add(Me.btnSchemeUpdate)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtSchemeTracker)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtSchmeInfo)
        Me.Controls.Add(Me.Label1)
        Me.Name = "UpdateScheme"
        Me.Text = "UpdateScheme"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents txtSchmeInfo As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtSchemeTracker As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents btnSchemeUpdate As Button
    Friend WithEvents cboSchemeStatus As ComboBox
End Class

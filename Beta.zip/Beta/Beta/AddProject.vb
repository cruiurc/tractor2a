﻿Imports System.Data
Imports System.Data.SqlClient
Public Class AddProject
    Public DC As New SqlConnection("server=" & SignIn.DB_ServerName & ";database=" & SignIn.DB_Name & ";user id=" & SignIn.DB_UserId & ";password=" & SignIn.DB_UserPW & ";")

    Private Sub btnAddProject_Click(sender As Object, e As EventArgs) Handles btnAddProject.Click
        If txtProjectName.Text = String.Empty Or txtProjectNumber.Text = String.Empty Or txtProjectManager.Text = String.Empty Or txtProjectAmount.Text = String.Empty Then
            MessageBox.Show("不能为空", ToString)
        Else
            Dim SqlAddProject As New SqlCommand("INSERT INTO Project (project_name, project_number, project_manager, project_amount, update_author, update_time, start_time, project_author) VALUES ('" & txtProjectName.Text.Trim() & "', '" & txtProjectNumber.Text.Trim() & "', '" & txtProjectManager.Text.Trim() & "', '" & txtProjectAmount.Text.Trim() & "', '" & Main.UserName & "', '" & Now.ToString & "', '" & Now.ToString & "', '" & Main.UserName & "')", DC)

            DC.Open()
            SqlAddProject.ExecuteNonQuery()
            DC.Close()
            MessageBox.Show("添加成功", ToString)
            '更新项目列表
            Dim projectDataAdapter As New SqlDataAdapter("SELECT project_id, project_number, project_name FROM Project WHERE project_name LIKE '%" & Main.Keyword & "%'", DC)
            Dim projectDataSet As New DataSet
            projectDataAdapter.Fill(projectDataSet, "project")
            Main.dgvProject.DataSource = projectDataSet
            Main.dgvProject.DataMember = "project"
            Main.dgvProject.Refresh()
            Me.Hide()
        End If

    End Sub
End Class
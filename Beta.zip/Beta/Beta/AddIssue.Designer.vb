﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AddIssue
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。  
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtIssueInfo = New System.Windows.Forms.TextBox()
        Me.txtIssueTracker = New System.Windows.Forms.TextBox()
        Me.btnAddIssue = New System.Windows.Forms.Button()
        Me.txtInfo = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(203, 149)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(113, 12)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Issue Information:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(205, 212)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(89, 12)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Issue tracker:"
        '
        'txtIssueInfo
        '
        Me.txtIssueInfo.Location = New System.Drawing.Point(324, 149)
        Me.txtIssueInfo.Multiline = True
        Me.txtIssueInfo.Name = "txtIssueInfo"
        Me.txtIssueInfo.Size = New System.Drawing.Size(260, 57)
        Me.txtIssueInfo.TabIndex = 3
        '
        'txtIssueTracker
        '
        Me.txtIssueTracker.Location = New System.Drawing.Point(324, 212)
        Me.txtIssueTracker.Name = "txtIssueTracker"
        Me.txtIssueTracker.Size = New System.Drawing.Size(100, 21)
        Me.txtIssueTracker.TabIndex = 4
        '
        'btnAddIssue
        '
        Me.btnAddIssue.Location = New System.Drawing.Point(324, 252)
        Me.btnAddIssue.Name = "btnAddIssue"
        Me.btnAddIssue.Size = New System.Drawing.Size(75, 23)
        Me.btnAddIssue.TabIndex = 5
        Me.btnAddIssue.Text = "Add"
        Me.btnAddIssue.UseVisualStyleBackColor = True
        '
        'txtInfo
        '
        Me.txtInfo.Location = New System.Drawing.Point(205, 74)
        Me.txtInfo.Multiline = True
        Me.txtInfo.Name = "txtInfo"
        Me.txtInfo.ReadOnly = True
        Me.txtInfo.Size = New System.Drawing.Size(379, 69)
        Me.txtInfo.TabIndex = 6
        '
        'AddIssue
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.txtInfo)
        Me.Controls.Add(Me.btnAddIssue)
        Me.Controls.Add(Me.txtIssueTracker)
        Me.Controls.Add(Me.txtIssueInfo)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Name = "AddIssue"
        Me.Text = "AddIssue"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents txtIssueInfo As TextBox
    Friend WithEvents txtIssueTracker As TextBox
    Friend WithEvents btnAddIssue As Button
    Friend WithEvents txtInfo As TextBox
End Class

﻿'author by crui 2018-12-06 pm @NJ
Imports System.Data
Imports System.Data.SqlClient

Public Class Main

    Public DC As New SqlConnection("server=" & SignIn.DB_ServerName & ";database=" & SignIn.DB_Name & ";user id=" & SignIn.DB_UserId & ";password=" & SignIn.DB_UserPW & ";")
    Public Keyword As String
    Public UserName As String
    Public chosenProjectID As Integer
    Public ProjectName As String
    Public chosenIssueID As Integer
    Public chosenSchemeID As Integer
    Public chosenActionID As Integer
    Public chosenReviewID As Integer
    '窗体加载时
    Private Sub Main_Load(sender As Object, e As EventArgs) Handles Me.Load
        '显示用户姓名
        Dim userDataAdapter As New SqlDataAdapter("SELECT user_name FROM Users WHERE user_id = '" & SignIn.txtUserId.Text.Trim() & "'", DC)
        Dim userDataSet As New DataSet
        userDataAdapter.Fill(userDataSet, "user")
        Dim userDataView As New DataView(userDataSet.Tables("user"))
        '初始化顶部用户标签的绑定数据，然后绑定查询结果到这个标签，用来显示用户名
        lblUserName.DataBindings.Clear()
        lblUserName.DataBindings.Add("Text", userDataView, "user_name")
        UserName = lblUserName.Text.Trim()
        '显示focus-issue
        Dim focusIssueDataAdapter As New SqlDataAdapter("SELECT issue_id, issue_info FROM Issue WHERE issue_tracker LIKE '%" & UserName & "%' AND issue_status <> 'closed （关闭）'", DC)
        Dim focusIssueDataSet As New DataSet
        focusIssueDataAdapter.Fill(focusIssueDataSet, "focusIssue")
        dgvFocusIssue.DataSource = focusIssueDataSet
        dgvFocusIssue.DataMember = "focusIssue"
        '显示focus-scheme
        Dim focusschemeDataAdapter As New SqlDataAdapter("SELECT scheme_id, scheme_info FROM Scheme LEFT JOIN Issue ON Scheme.issue_id = Issue.issue_id WHERE scheme_tracker LIKE '%" & UserName & "%' AND scheme_status <> '关闭'", DC)
        Dim focusSchemeDataSet As New DataSet
        focusschemeDataAdapter.Fill(focusSchemeDataSet, "focusScheme")
        dgvFocusScheme.DataSource = focusSchemeDataSet
        dgvFocusScheme.DataMember = "focusScheme"
        '显示focus-action
        Dim focusactionDataAdapter As New SqlDataAdapter("SELECT action_id, action_info FROM Action LEFT JOIN Scheme ON Action.scheme_id = Scheme.scheme_id LEFT JOIN Issue ON Scheme.issue_id = Issue.issue_id WHERE action_tracker LIKE '%" & UserName & "%' AND action_status <> '关闭'", DC)
        Dim focusactionDataSet As New DataSet
        focusactionDataAdapter.Fill(focusactionDataSet, "focusaction")
        dgvFocusAction.DataSource = focusactionDataSet
        dgvFocusAction.DataMember = "focusaction"

        '显示项目列表
        Dim projectDataAdapter As New SqlDataAdapter("SELECT project_id, project_number, project_name FROM Project WHERE project_name LIKE '%" & Keyword & "%'", DC)
        Dim projectDataSet As New DataSet
        projectDataAdapter.Fill(projectDataSet, "project")
        dgvProject.DataSource = projectDataSet
        dgvProject.DataMember = "project"

    End Sub

    '点击page1

    Private Sub tab_Selected(sender As Object, e As TabControlEventArgs) Handles tab.Selected
        If e.TabPage.TabIndex = TabPage1.TabIndex Then
            '显示focus-issue
            Dim focusIssueDataAdapter As New SqlDataAdapter("SELECT issue_id, issue_info FROM Issue WHERE issue_tracker LIKE '%" & UserName & "%' AND issue_status <> 'closed （关闭）'", DC)
            Dim focusIssueDataSet As New DataSet
            focusIssueDataAdapter.Fill(focusIssueDataSet, "focusIssue")
            dgvFocusIssue.DataSource = focusIssueDataSet
            dgvFocusIssue.DataMember = "focusIssue"
            '显示focus-scheme
            Dim focusschemeDataAdapter As New SqlDataAdapter("SELECT scheme_id, scheme_info FROM Scheme LEFT JOIN Issue ON Scheme.issue_id = Issue.issue_id WHERE scheme_tracker LIKE '%" & UserName & "%' AND scheme_status <> '关闭'", DC)
            Dim focusSchemeDataSet As New DataSet
            focusschemeDataAdapter.Fill(focusSchemeDataSet, "focusScheme")
            dgvFocusScheme.DataSource = focusSchemeDataSet
            dgvFocusScheme.DataMember = "focusScheme"
            '显示focus-action
            Dim focusactionDataAdapter As New SqlDataAdapter("SELECT action_id, action_info FROM Action LEFT JOIN Scheme ON Action.scheme_id = Scheme.scheme_id LEFT JOIN Issue ON Scheme.issue_id = Issue.issue_id WHERE action_tracker LIKE '%" & UserName & "%' AND action_status <> '关闭'", DC)
            Dim focusactionDataSet As New DataSet
            focusactionDataAdapter.Fill(focusactionDataSet, "focusaction")
            dgvFocusAction.DataSource = focusactionDataSet
            dgvFocusAction.DataMember = "focusaction"
        End If
    End Sub


    '点击查询按钮
    Private Sub btnSearchProject_Click(sender As Object, e As EventArgs) Handles btnSearchProject.Click
        Keyword = txtKeyword.Text.Trim()
        '查询和更新项目列表
        Dim projectDataAdapter As New SqlDataAdapter("SELECT project_id, project_number, project_name FROM Project WHERE project_name LIKE '%" & Keyword & "%'", DC)
        Dim projectDataSet As New DataSet
        projectDataAdapter.Fill(projectDataSet, "project")
        dgvProject.DataSource = projectDataSet
        dgvProject.DataMember = "project"
    End Sub
    '点击添加项目链接，打开添加项目窗体
    Private Sub llbAddProject_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llbAddProject.LinkClicked
        AddProject.txtProjectName.Text = Nothing
        AddProject.txtProjectNumber.Text = Nothing
        AddProject.txtProjectManager.Text = Nothing
        AddProject.txtProjectAmount.Text = Nothing
        AddProject.Show()
    End Sub



    '单击项目列表事件，选中行并查询到整行数据，用于给右上的标签赋值
    Private Sub dgvProject_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvProject.CellClick
        Dim selected = dgvProject.CurrentRow.Index
        chosenProjectID = dgvProject.Rows(selected).Cells(0).Value
        Dim projectDataAdapter As New SqlDataAdapter("SELECT * FROM Project WHERE project_id = '" & chosenProjectID & "'", DC)
        Dim projectDataSet As New DataSet
        projectDataAdapter.Fill(projectDataSet, "project")

        '初始化ProjectInfo组合框中标签TEXT的绑定，然后绑定查询结果到这些标签
        Dim projectDataView As New DataView(projectDataSet.Tables("project"))
        lblProjectInfoName.DataBindings.Clear()
        lblProjectInfoNumber.DataBindings.Clear()
        lblProjectInfoManager.DataBindings.Clear()
        lblProjectInfoAmount.DataBindings.Clear()
        lblProjectInfoName.DataBindings.Add("Text", projectDataView, "project_name")
        lblProjectInfoNumber.DataBindings.Add("Text", projectDataView, "project_number")
        lblProjectInfoManager.DataBindings.Add("Text", projectDataView, "project_manager")
        lblProjectInfoAmount.DataBindings.Add("Text", projectDataView, "project_amount")
        '在右上角的标签中显示项目名称
        ProjectName = lblProjectInfoName.Text
        lblProjectName.Text = ProjectName



        '显示事件列表
        Dim issueDataAdapter As New SqlDataAdapter("SELECT issue_id, issue_info, issue_tracker, issue_status FROM Issue WHERE project_id = '" & chosenProjectID & "'", DC)
        Dim issueDataSet As New DataSet
        issueDataAdapter.Fill(issueDataSet, "issue")
        dgvIssue.DataSource = issueDataSet
        dgvIssue.DataMember = "issue"
        grpProject.Show()
        grpIssue.Show()



    End Sub
    '添加事件
    Private Sub llbAddIssue_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llbAddIssue.LinkClicked
        If chosenProjectID = Nothing Then
            MessageBox.Show("未选定项目，无法添加事件！", ToString)
        Else
            AddIssue.txtIssueInfo.Text = Nothing
            AddIssue.txtIssueTracker.Text = Nothing
            AddIssue.Show()
        End If
    End Sub
    '更新项目
    Private Sub llbUpdatePorject_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llbUpdatePorject.LinkClicked
        If chosenProjectID = Nothing Then
            MessageBox.Show("未选定项目，无法更新项目！", ToString)
        Else
            UpdateProject.txtProjectName.Text = lblProjectInfoName.Text
            UpdateProject.txtProjectNumber.Text = lblProjectInfoNumber.Text
            UpdateProject.txtProjectManager.Text = lblProjectInfoManager.Text
            UpdateProject.txtProjectAmount.Text = lblProjectInfoAmount.Text

            UpdateProject.Show()
        End If
    End Sub

    '点击事件列表，根据点击的事件赋值到第三页的Scheme表和标签
    Private Sub dgvIssue_Click(sender As Object, e As EventArgs) Handles dgvIssue.Click
        Dim selected = dgvIssue.CurrentRow.Index
        chosenIssueID = dgvIssue.Rows(selected).Cells(0).Value
        Dim SchemeDataAdapter As New SqlDataAdapter("SELECT scheme_id, update_author FROM Scheme WHERE issue_id = '" & chosenIssueID & "'", DC)
        Dim SchemeDataSet As New DataSet
        SchemeDataAdapter.Fill(SchemeDataSet, "Scheme")
        dgvScheme.DataSource = SchemeDataSet
        dgvScheme.DataMember = "Scheme"

        '赋值到右侧的Comment、Attachment和Review列表
        Dim CommentDataAdapter As New SqlDataAdapter("SELECT comment_info FROM Comment WHERE issue_id = '" & chosenIssueID & "' ORDER BY comment_id", DC)
        Dim CommentDataSet As New DataSet
        CommentDataAdapter.Fill(CommentDataSet, "comment")
        dgvComment.DataSource = CommentDataSet
        dgvComment.DataMember = "comment"
        Dim AttachmentDataAdapter As New SqlDataAdapter("SELECT * FROM Attachment WHERE issue_id = '" & chosenIssueID & "'", DC)
        Dim AttachmentDataSet As New DataSet
        AttachmentDataAdapter.Fill(AttachmentDataSet, "attachment")
        dgvAttachment.DataSource = AttachmentDataSet
        dgvAttachment.DataMember = "attachment"
        Dim ReviewDataAdapter As New SqlDataAdapter("SELECT review_id, review_info FROM Review WHERE issue_id = '" & chosenIssueID & "'", DC)
        Dim ReviewDataSet As New DataSet
        ReviewDataAdapter.Fill(ReviewDataSet, "review")
        dgvReview.DataSource = ReviewDataSet
        dgvReview.DataMember = "review"


        '初始化Issue info组合框中标签TEXT的绑定，然后绑定查询结果到这些标签
        Dim IssueDataAdapter As New SqlDataAdapter("SELECT * FROM Issue WHERE issue_id = '" & chosenIssueID & "'", DC)
        Dim IssueDataSet As New DataSet
        IssueDataAdapter.Fill(IssueDataSet, "project")
        Dim IssueDataView As New DataView(IssueDataSet.Tables("project"))
        txtIssueInfo.DataBindings.Clear()
        lblIssueInfoTracker.DataBindings.Clear()
        lblIssueInfoStatus.DataBindings.Clear()
        lblIssueInfoUpdateAuthor.DataBindings.Clear()
        lblIssueInfoUpdateTime.DataBindings.Clear()
        lblIssueInfoStartTime.DataBindings.Clear()
        lblIssueInfoAuthor.DataBindings.Clear()
        lblIssueInfoResolution.DataBindings.Clear()

        txtIssueInfo.DataBindings.Add("Text", IssueDataView, "issue_info")
        lblIssueInfoTracker.DataBindings.Add("Text", IssueDataView, "issue_tracker")
        lblIssueInfoStatus.DataBindings.Add("Text", IssueDataView, "issue_status")
        lblIssueInfoUpdateAuthor.DataBindings.Add("Text", IssueDataView, "update_author")
        lblIssueInfoUpdateTime.DataBindings.Add("Text", IssueDataView, "update_time")
        lblIssueInfoStartTime.DataBindings.Add("Text", IssueDataView, "start_time")
        lblIssueInfoAuthor.DataBindings.Add("Text", IssueDataView, "issue_author")
        lblIssueInfoResolution.DataBindings.Add("Text", IssueDataView, "issue_resolution")

        tab.SelectTab(2)

    End Sub

    Private Sub llbUpdateIssue_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llbUpdateIssue.LinkClicked
        If chosenIssueID = Nothing Then
            MessageBox.Show("未选定事件，无法更新事件信息！", ToString)
        Else
            UpdateIssue.txtIssueInfo.Text = txtIssueInfo.Text
            UpdateIssue.txtIssueTracker.Text = lblIssueInfoTracker.Text
            UpdateIssue.cboIssueStatus.Text = lblIssueInfoStatus.Text
            UpdateIssue.cboIssueResolution.Text = lblIssueInfoResolution.Text

            UpdateIssue.Show()
        End If

    End Sub
    '添加Scheme
    Private Sub llbAddScheme_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llbAddScheme.LinkClicked
        If chosenIssueID = Nothing Then
            MessageBox.Show("未选定事件，无法添加方案！", ToString)
        Else
            AddScheme.txtSchemeInfo.Text = Nothing
            AddScheme.txtSchemeTracker.Text = Nothing

            AddScheme.Show()
        End If
    End Sub

    '点击Scheme列表
    Private Sub dgvScheme_Click(sender As Object, e As EventArgs) Handles dgvScheme.Click
        Dim selected = dgvScheme.CurrentRow.Index
        chosenSchemeID = dgvScheme.Rows(selected).Cells(0).Value
        '赋值到右侧SchemeInfo标签
        Dim SchemeDataAdapter As New SqlDataAdapter("SELECT * FROM Scheme WHERE scheme_id = '" & chosenSchemeID & "'", DC)
        Dim SchemeDataSet As New DataSet
        SchemeDataAdapter.Fill(SchemeDataSet, "scheme")

        Dim SchemeDataView As New DataView(SchemeDataSet.Tables("scheme"))
        txtSchemeInfo.DataBindings.Clear()
        lblSchemeAuthor.DataBindings.Clear()
        lblSchemeStartTime.DataBindings.Clear()
        lblSchemeStatus.DataBindings.Clear()
        lblSchemeTracker.DataBindings.Clear()
        lblSchemeUpdateAuthor.DataBindings.Clear()
        lblSchemeUpdateTime.DataBindings.Clear()

        txtSchemeInfo.DataBindings.Add("Text", SchemeDataView, "scheme_info")
        lblSchemeAuthor.DataBindings.Add("Text", SchemeDataView, "scheme_author")
        lblSchemeStartTime.DataBindings.Add("Text", SchemeDataView, "start_time")
        lblSchemeStatus.DataBindings.Add("Text", SchemeDataView, "scheme_status")
        lblSchemeTracker.DataBindings.Add("Text", SchemeDataView, "scheme_tracker")
        lblSchemeUpdateAuthor.DataBindings.Add("Text", SchemeDataView, "update_author")
        lblSchemeUpdateTime.DataBindings.Add("Text", SchemeDataView, "update_time")
        '赋值到下方的Action列表
        Dim ActionDataAdapter As New SqlDataAdapter("SELECT action_id, action_due, action_status FROM Action WHERE scheme_id = '" & chosenSchemeID & "'", DC)
        Dim ActionDataSet As New DataSet
        ActionDataAdapter.Fill(ActionDataSet, "action")
        dgvAction.DataSource = ActionDataSet
        dgvAction.DataMember = "Action"



    End Sub
    '点击Update scheme链接
    Private Sub llbUpdateScheme_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llbUpdateScheme.LinkClicked
        If chosenSchemeID = Nothing Then
            MessageBox.Show("未选定方案，无法更新方案信息！", ToString)
        Else
            UpdateScheme.txtSchmeInfo.Text = txtSchemeInfo.Text
            UpdateScheme.txtSchemeTracker.Text = lblSchemeTracker.Text
            UpdateScheme.cboSchemeStatus.Text = lblSchemeStatus.Text

            UpdateScheme.Show()
        End If
    End Sub
    '添加action
    Private Sub llbAddAction_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llbAddAction.LinkClicked
        If chosenSchemeID = Nothing Then
            MessageBox.Show("未选定方案，无法添加行动！", ToString)
        Else
            AddAction.txtActionInfo.Text = Nothing
            AddAction.txtActionTracker.Text = Nothing

            AddAction.Show()
        End If

    End Sub
    '点击action list
    Private Sub dgvAction_Click(sender As Object, e As EventArgs) Handles dgvAction.Click
        Dim selected = dgvAction.CurrentRow.Index
        chosenActionID = dgvAction.Rows(selected).Cells(0).Value
        '赋值到右侧ActionInfo标签
        Dim actionDataAdapter As New SqlDataAdapter("SELECT * FROM Action WHERE action_id = '" & chosenActionID & "'", DC)
        Dim actionDataSet As New DataSet
        actionDataAdapter.Fill(actionDataSet, "action")

        Dim actionDataView As New DataView(actionDataSet.Tables("action"))
        txtActionInfo.DataBindings.Clear()
        lblActionAuthor.DataBindings.Clear()
        lblActionStart.DataBindings.Clear()
        lblActionStatus.DataBindings.Clear()
        lblActionTracker.DataBindings.Clear()
        lblActionUpdateAuthor.DataBindings.Clear()
        lblActionUpdateTime.DataBindings.Clear()

        txtActionInfo.DataBindings.Add("Text", actionDataView, "action_info")
        lblActionAuthor.DataBindings.Add("Text", actionDataView, "action_author")
        lblActionStart.DataBindings.Add("Text", actionDataView, "start_time")
        lblActionStatus.DataBindings.Add("Text", actionDataView, "action_status")
        lblActionTracker.DataBindings.Add("Text", actionDataView, "action_tracker")
        lblActionUpdateAuthor.DataBindings.Add("Text", actionDataView, "update_author")
        lblActionUpdateTime.DataBindings.Add("Text", actionDataView, "update_time")
        'grpAction.Refresh()
    End Sub


    'update action
    Private Sub llbActionUpdate_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llbActionUpdate.LinkClicked
        If chosenActionID = Nothing Then
            MessageBox.Show("未选定行动，无法更新行动信息！", ToString)
        Else
            UpdateAction.txtActionInfo.Text = txtActionInfo.Text
            UpdateAction.txtActionTracker.Text = lblActionTracker.Text
            UpdateAction.cboActionStatus.Text = lblActionStatus.Text
            UpdateAction.txtActionDue.Text = lblActionDue.Text.ToString
            UpdateAction.Show()
        End If
    End Sub
    '添加Comment
    Private Sub llbAddComment_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llbAddComment.LinkClicked
        If chosenIssueID = Nothing Then
            MessageBox.Show("未选定事件，无法添加评论！", ToString)
        Else
            AddComment.txtCommentInfo.Text = Nothing

            AddComment.Show()
        End If
    End Sub
    '添加Review
    Private Sub llbAddReview_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llbAddReview.LinkClicked
        If chosenIssueID = Nothing Then
            MessageBox.Show("未选定事件，无法添加评论！", ToString)
        Else
            AddReview.txtReviewInfo.Text = Nothing
            AddReview.txtReviewCost.Text = 0
            AddReview.txtReviewDelay.Text = 0
            AddReview.txtReviewTracker.Text = Nothing

            AddReview.Show()
        End If
    End Sub

    '点击Review list
    Private Sub dgvReview_Click(sender As Object, e As EventArgs) Handles dgvReview.Click
        Dim selected = dgvReview.CurrentRow.Index
        chosenReviewID = dgvReview.Rows(selected).Cells(0).Value
        '赋值到下方TEXTINFO
        Dim reviewDataAdapter As New SqlDataAdapter("SELECT * FROM Review WHERE review_id = '" & chosenReviewID & "'", DC)
        Dim reviewDataSet As New DataSet
        reviewDataAdapter.Fill(reviewDataSet, "review")

        Dim reviewDataView As New DataView(reviewDataSet.Tables("review"))

        txtReviewInfo.DataBindings.Clear()
        lblReviewCost.DataBindings.Clear()
        lblReviewDelay.DataBindings.Clear()
        lblReviewStatus.DataBindings.Clear()
        lblReviewTracker.DataBindings.Clear()
        lblReviewUpdateAuthor.DataBindings.Clear()



        txtReviewInfo.DataBindings.Add("Text", reviewDataView, "review_info")
        lblReviewCost.DataBindings.Add("Text", reviewDataView, "review_cost")
        lblReviewDelay.DataBindings.Add("Text", reviewDataView, "review_delay")
        lblReviewStatus.DataBindings.Add("Text", reviewDataView, "review_status")
        lblReviewTracker.DataBindings.Add("Text", reviewDataView, "review_tracker")
        lblReviewUpdateAuthor.DataBindings.Add("Text", reviewDataView, "update_author")


    End Sub
    '点击FocusIssue列表
    Private Sub dgvFocusIssue_Click(sender As Object, e As EventArgs) Handles dgvFocusIssue.Click
        Dim selected = dgvFocusIssue.CurrentRow.Index
        chosenIssueID = dgvFocusIssue.Rows(selected).Cells(0).Value
        Dim SchemeDataAdapter As New SqlDataAdapter("SELECT scheme_id, scheme_tracker FROM Scheme WHERE issue_id = '" & chosenIssueID & "'", DC)
        Dim SchemeDataSet As New DataSet
        SchemeDataAdapter.Fill(SchemeDataSet, "Scheme")
        dgvScheme.DataSource = SchemeDataSet
        dgvScheme.DataMember = "Scheme"

        '赋值到右侧的Comment、Attachment和Review列表
        Dim CommentDataAdapter As New SqlDataAdapter("SELECT comment_info FROM Comment WHERE issue_id = '" & chosenIssueID & "' ORDER BY comment_id", DC)
        Dim CommentDataSet As New DataSet
        CommentDataAdapter.Fill(CommentDataSet, "comment")
        dgvComment.DataSource = CommentDataSet
        dgvComment.DataMember = "comment"
        Dim AttachmentDataAdapter As New SqlDataAdapter("SELECT * FROM Attachment WHERE issue_id = '" & chosenIssueID & "'", DC)
        Dim AttachmentDataSet As New DataSet
        AttachmentDataAdapter.Fill(AttachmentDataSet, "attachment")
        dgvAttachment.DataSource = AttachmentDataSet
        dgvAttachment.DataMember = "attachment"
        Dim ReviewDataAdapter As New SqlDataAdapter("SELECT review_id, review_info FROM Review WHERE issue_id = '" & chosenIssueID & "'", DC)
        Dim ReviewDataSet As New DataSet
        ReviewDataAdapter.Fill(ReviewDataSet, "review")
        dgvReview.DataSource = ReviewDataSet
        dgvReview.DataMember = "review"


        '初始化Issue info组合框中标签TEXT的绑定，然后绑定查询结果到这些标签
        Dim IssueDataAdapter As New SqlDataAdapter("SELECT * FROM Issue WHERE issue_id = '" & chosenIssueID & "'", DC)
        Dim IssueDataSet As New DataSet
        IssueDataAdapter.Fill(IssueDataSet, "project")
        Dim IssueDataView As New DataView(IssueDataSet.Tables("project"))
        txtIssueInfo.DataBindings.Clear()
        lblIssueInfoTracker.DataBindings.Clear()
        lblIssueInfoStatus.DataBindings.Clear()
        lblIssueInfoUpdateAuthor.DataBindings.Clear()
        lblIssueInfoUpdateTime.DataBindings.Clear()
        lblIssueInfoStartTime.DataBindings.Clear()
        lblIssueInfoAuthor.DataBindings.Clear()
        lblIssueInfoResolution.DataBindings.Clear()

        txtIssueInfo.DataBindings.Add("Text", IssueDataView, "issue_info")
        lblIssueInfoTracker.DataBindings.Add("Text", IssueDataView, "issue_tracker")
        lblIssueInfoStatus.DataBindings.Add("Text", IssueDataView, "issue_status")
        lblIssueInfoUpdateAuthor.DataBindings.Add("Text", IssueDataView, "update_author")
        lblIssueInfoUpdateTime.DataBindings.Add("Text", IssueDataView, "update_time")
        lblIssueInfoStartTime.DataBindings.Add("Text", IssueDataView, "start_time")
        lblIssueInfoAuthor.DataBindings.Add("Text", IssueDataView, "issue_author")
        lblIssueInfoResolution.DataBindings.Add("Text", IssueDataView, "issue_resolution")

        tab.SelectTab(2)
    End Sub
    '点击FocusScheme列表
    Private Sub dgvFocusScheme_Click(sender As Object, e As EventArgs) Handles dgvFocusScheme.Click
        Dim selected = dgvFocusScheme.CurrentRow.Index
        chosenIssueID = dgvFocusScheme.Rows(selected).Cells(0).Value
        Dim SchemeDataAdapter As New SqlDataAdapter("SELECT scheme_id, scheme_tracker FROM Scheme WHERE issue_id = '" & chosenIssueID & "'", DC)
        Dim SchemeDataSet As New DataSet
        SchemeDataAdapter.Fill(SchemeDataSet, "Scheme")
        dgvScheme.DataSource = SchemeDataSet
        dgvScheme.DataMember = "Scheme"

        '赋值到右侧的Comment、Attachment和Review列表
        Dim CommentDataAdapter As New SqlDataAdapter("SELECT comment_info FROM Comment WHERE issue_id = '" & chosenIssueID & "' ORDER BY comment_id", DC)
        Dim CommentDataSet As New DataSet
        CommentDataAdapter.Fill(CommentDataSet, "comment")
        dgvComment.DataSource = CommentDataSet
        dgvComment.DataMember = "comment"
        Dim AttachmentDataAdapter As New SqlDataAdapter("SELECT * FROM Attachment WHERE issue_id = '" & chosenIssueID & "'", DC)
        Dim AttachmentDataSet As New DataSet
        AttachmentDataAdapter.Fill(AttachmentDataSet, "attachment")
        dgvAttachment.DataSource = AttachmentDataSet
        dgvAttachment.DataMember = "attachment"
        Dim ReviewDataAdapter As New SqlDataAdapter("SELECT review_id, review_info FROM Review WHERE issue_id = '" & chosenIssueID & "'", DC)
        Dim ReviewDataSet As New DataSet
        ReviewDataAdapter.Fill(ReviewDataSet, "review")
        dgvReview.DataSource = ReviewDataSet
        dgvReview.DataMember = "review"


        '初始化Issue info组合框中标签TEXT的绑定，然后绑定查询结果到这些标签
        Dim IssueDataAdapter As New SqlDataAdapter("SELECT * FROM Issue WHERE issue_id = '" & chosenIssueID & "'", DC)
        Dim IssueDataSet As New DataSet
        IssueDataAdapter.Fill(IssueDataSet, "project")
        Dim IssueDataView As New DataView(IssueDataSet.Tables("project"))
        txtIssueInfo.DataBindings.Clear()
        lblIssueInfoTracker.DataBindings.Clear()
        lblIssueInfoStatus.DataBindings.Clear()
        lblIssueInfoUpdateAuthor.DataBindings.Clear()
        lblIssueInfoUpdateTime.DataBindings.Clear()
        lblIssueInfoStartTime.DataBindings.Clear()
        lblIssueInfoAuthor.DataBindings.Clear()
        lblIssueInfoResolution.DataBindings.Clear()

        txtIssueInfo.DataBindings.Add("Text", IssueDataView, "issue_info")
        lblIssueInfoTracker.DataBindings.Add("Text", IssueDataView, "issue_tracker")
        lblIssueInfoStatus.DataBindings.Add("Text", IssueDataView, "issue_status")
        lblIssueInfoUpdateAuthor.DataBindings.Add("Text", IssueDataView, "update_author")
        lblIssueInfoUpdateTime.DataBindings.Add("Text", IssueDataView, "update_time")
        lblIssueInfoStartTime.DataBindings.Add("Text", IssueDataView, "start_time")
        lblIssueInfoAuthor.DataBindings.Add("Text", IssueDataView, "issue_author")
        lblIssueInfoResolution.DataBindings.Add("Text", IssueDataView, "issue_resolution")

        tab.SelectTab(2)
    End Sub
    '点击FocusAction列表
    Private Sub dgvFocusAction_Click(sender As Object, e As EventArgs) Handles dgvFocusAction.Click
        Dim selected = dgvFocusAction.CurrentRow.Index
        chosenIssueID = dgvFocusAction.Rows(selected).Cells(0).Value

        Dim SchemeDataAdapter As New SqlDataAdapter("SELECT scheme_id, scheme_tracker FROM Scheme WHERE issue_id = '" & chosenIssueID & "'", DC)
        Dim SchemeDataSet As New DataSet
        SchemeDataAdapter.Fill(SchemeDataSet, "Scheme")
        dgvScheme.DataSource = SchemeDataSet
        dgvScheme.DataMember = "Scheme"

        '赋值到右侧的Comment、Attachment和Review列表
        Dim CommentDataAdapter As New SqlDataAdapter("SELECT comment_info FROM Comment WHERE issue_id = '" & chosenIssueID & "' ORDER BY comment_id", DC)
        Dim CommentDataSet As New DataSet
        CommentDataAdapter.Fill(CommentDataSet, "comment")
        dgvComment.DataSource = CommentDataSet
        dgvComment.DataMember = "comment"
        Dim AttachmentDataAdapter As New SqlDataAdapter("SELECT * FROM Attachment WHERE issue_id = '" & chosenIssueID & "'", DC)
        Dim AttachmentDataSet As New DataSet
        AttachmentDataAdapter.Fill(AttachmentDataSet, "attachment")
        dgvAttachment.DataSource = AttachmentDataSet
        dgvAttachment.DataMember = "attachment"
        Dim ReviewDataAdapter As New SqlDataAdapter("SELECT review_id, review_info FROM Review WHERE issue_id = '" & chosenIssueID & "'", DC)
        Dim ReviewDataSet As New DataSet
        ReviewDataAdapter.Fill(ReviewDataSet, "review")
        dgvReview.DataSource = ReviewDataSet
        dgvReview.DataMember = "review"


        '初始化Issue info组合框中标签TEXT的绑定，然后绑定查询结果到这些标签
        Dim IssueDataAdapter As New SqlDataAdapter("SELECT * FROM Issue WHERE issue_id = '" & chosenIssueID & "'", DC)
        Dim IssueDataSet As New DataSet
        IssueDataAdapter.Fill(IssueDataSet, "project")
        Dim IssueDataView As New DataView(IssueDataSet.Tables("project"))
        txtIssueInfo.DataBindings.Clear()
        lblIssueInfoTracker.DataBindings.Clear()
        lblIssueInfoStatus.DataBindings.Clear()
        lblIssueInfoUpdateAuthor.DataBindings.Clear()
        lblIssueInfoUpdateTime.DataBindings.Clear()
        lblIssueInfoStartTime.DataBindings.Clear()
        lblIssueInfoAuthor.DataBindings.Clear()
        lblIssueInfoResolution.DataBindings.Clear()

        txtIssueInfo.DataBindings.Add("Text", IssueDataView, "issue_info")
        lblIssueInfoTracker.DataBindings.Add("Text", IssueDataView, "issue_tracker")
        lblIssueInfoStatus.DataBindings.Add("Text", IssueDataView, "issue_status")
        lblIssueInfoUpdateAuthor.DataBindings.Add("Text", IssueDataView, "update_author")
        lblIssueInfoUpdateTime.DataBindings.Add("Text", IssueDataView, "update_time")
        lblIssueInfoStartTime.DataBindings.Add("Text", IssueDataView, "start_time")
        lblIssueInfoAuthor.DataBindings.Add("Text", IssueDataView, "issue_author")
        lblIssueInfoResolution.DataBindings.Add("Text", IssueDataView, "issue_resolution")

        tab.SelectTab(2)
    End Sub

End Class
﻿Imports System.Data
Imports System.Data.SqlClient

Public Class UpdateAction
    Public DC As New SqlConnection("server=" & SignIn.DB_ServerName & ";database=" & SignIn.DB_Name & ";user id=" & SignIn.DB_UserId & ";password=" & SignIn.DB_UserPW & ";")

    Private Sub DateTimePicker1_ValueChanged(sender As Object, e As EventArgs) Handles dtpActionDue.ValueChanged
        txtActionDue.Text = dtpActionDue.Text
    End Sub
    Private Sub btnUpdateAction_Click(sender As Object, e As EventArgs) Handles btnUpdateAction.Click
        If txtActionInfo.Text = String.Empty Or cboActionStatus.Text = String.Empty Then
            MessageBox.Show("Info/Status不能为空", ToString)
        Else
            Dim SqlUpdateAction As New SqlCommand("UPDATE Action SET action_info = '" & txtActionInfo.Text & "', action_status = '" & cboActionStatus.Text & "', action_due = '" & txtActionDue.Text & "', action_tracker = '" & txtActionTracker.Text.Trim() & "', update_author = '" & Main.UserName & "', update_time = '" & Now.ToString & "' WHERE action_id = '" & Main.chosenActionID & "'", DC)

            DC.Open()
            SqlUpdateAction.ExecuteNonQuery()
            DC.Close()
            MessageBox.Show("更新成功", ToString)

            '初始化ActionInfo组合框中标签TEXT的绑定，然后绑定查询结果到这些标签
            Dim actionAllDataAdapter As New SqlDataAdapter("SELECT * FROM Action WHERE action_id = '" & Main.chosenActionID & "'", DC)
            Dim actionAllDataSet As New DataSet
            actionAllDataAdapter.Fill(actionAllDataSet, "actionAll")

            Dim SchemeDataView As New DataView(actionAllDataSet.Tables("actionAll"))
            Main.txtActionInfo.DataBindings.Clear()
            Main.lblActionAuthor.DataBindings.Clear()
            Main.lblActionStart.DataBindings.Clear()
            Main.lblActionStatus.DataBindings.Clear()
            Main.lblActionTracker.DataBindings.Clear()
            Main.lblActionUpdateAuthor.DataBindings.Clear()
            Main.lblActionUpdateTime.DataBindings.Clear()
            Main.lblActionDue.DataBindings.Clear()

            Main.txtActionInfo.DataBindings.Add("Text", SchemeDataView, "action_info")
            Main.lblActionAuthor.DataBindings.Add("Text", SchemeDataView, "action_author")
            Main.lblActionStart.DataBindings.Add("Text", SchemeDataView, "start_time")
            Main.lblActionStatus.DataBindings.Add("Text", SchemeDataView, "action_status")
            Main.lblActionTracker.DataBindings.Add("Text", SchemeDataView, "action_tracker")
            Main.lblActionUpdateAuthor.DataBindings.Add("Text", SchemeDataView, "update_author")
            Main.lblActionUpdateTime.DataBindings.Add("Text", SchemeDataView, "update_time")
            Main.lblActionDue.DataBindings.Add("Text", SchemeDataView, "action_due")

            '更新action列表
            Dim actionDataAdapter As New SqlDataAdapter("SELECT action_id, action_due, action_status FROM Action WHERE scheme_id = '" & Main.chosenSchemeID & "'", DC)
            Dim actionDataSet As New DataSet
            actionDataAdapter.Fill(actionDataSet, "action")
            Main.dgvIssue.DataSource = actionDataSet
            Main.dgvIssue.DataMember = "action"

            Me.Hide()
        End If

    End Sub


End Class